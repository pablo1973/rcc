# Estados Cognitivos

## Estados Base

### CALM
Estado de calma - sin intervención requerida.

### NEUTRAL
Estado neutro - baseline por defecto.

### TENSE
Estado tenso - puede requerir regulación.

## Límites
- Solo 3 estados
- Determinístico
- Sin estados intermedios
