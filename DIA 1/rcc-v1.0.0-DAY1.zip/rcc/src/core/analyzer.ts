import { InputMessage } from "./types";
import { CognitiveState } from "./states";
export interface Observation {
  state: CognitiveState;
}
export function analyze(_input: InputMessage): Observation {
  return {
    state: "NEUTRAL",
  };
}
