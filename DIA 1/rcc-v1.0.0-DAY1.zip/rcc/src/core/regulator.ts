import { InputMessage } from "./types";
import { Observation } from "./analyzer";
export interface RegulationResult {
  outputText: string;
}
export function regulate(
  input: InputMessage,
  _observation: Observation
): RegulationResult {
  return {
    outputText: input.text,
  };
}
