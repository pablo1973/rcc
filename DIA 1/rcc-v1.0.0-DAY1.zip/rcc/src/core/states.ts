export type CognitiveState = "CALM" | "NEUTRAL" | "TENSE";
