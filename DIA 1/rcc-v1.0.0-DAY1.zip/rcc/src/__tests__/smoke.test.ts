import { InputMessage, Channel } from "../core/types";
import { CognitiveState } from "../core/states";
import { analyze, Observation } from "../core/analyzer";
import { regulate, RegulationResult } from "../core/regulator";

describe("RCC Smoke Test", () => {
  const mockInput: InputMessage = {
    id: "test-1",
    text: "Hello world",
    author: "user",
    channel: "cli" as Channel,
    timestamp: Date.now(),
  };

  test("types are defined", () => {
    expect(mockInput.id).toBe("test-1");
    expect(mockInput.channel).toBe("cli");
  });

  test("CognitiveState type exists", () => {
    const state: CognitiveState = "NEUTRAL";
    expect(["CALM", "NEUTRAL", "TENSE"]).toContain(state);
  });

  test("analyze returns Observation with NEUTRAL state", () => {
    const observation: Observation = analyze(mockInput);
    expect(observation.state).toBe("NEUTRAL");
  });

  test("regulate returns RegulationResult with original text", () => {
    const observation: Observation = { state: "NEUTRAL" };
    const result: RegulationResult = regulate(mockInput, observation);
    expect(result.outputText).toBe("Hello world");
  });

  test("empty pipeline: input -> analyze -> regulate", () => {
    const input: InputMessage = {
      id: "pipe-1",
      text: "Test message",
      author: "tester",
      channel: "slack",
      timestamp: Date.now(),
    };
    const observation = analyze(input);
    const result = regulate(input, observation);
    expect(observation.state).toBe("NEUTRAL");
    expect(result.outputText).toBe("Test message");
  });
});
