# RCC Core

## Qué es RCC
Regulador Cognitivo Conversacional - pipeline determinístico de regulación.

## Qué problema resuelve
Regulación de tono e intención en conversaciones multi-canal.

## Qué NO es RCC
- No es IA/ML
- No es chatbot
- No tiene heurísticas complejas

## Rol del regulador
Transformar input según estado cognitivo observado.
