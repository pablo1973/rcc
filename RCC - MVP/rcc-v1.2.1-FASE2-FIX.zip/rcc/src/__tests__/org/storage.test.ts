/**
 * RCC-ORG Storage Tests
 */

import { 
  initDatabase, 
  insertMember, 
  insertMessage, 
  insertBatch,
  queryMessages, 
  queryMembers, 
  getStats,
  closeDatabase 
} from '../../org/storage';
import { Member, Message } from '../../org/types';

describe('Storage', () => {
  beforeEach(async () => {
    await initDatabase();
  });
  
  afterEach(() => {
    closeDatabase();
  });
  
  describe('member operations', () => {
    it('inserts and queries members', () => {
      const member: Member = { id: 'test-1', name: 'Juan' };
      insertMember(member);
      
      const members = queryMembers();
      expect(members).toHaveLength(1);
      expect(members[0].name).toBe('Juan');
    });
    
    it('handles duplicate member inserts', () => {
      const member: Member = { id: 'test-1', name: 'Juan' };
      insertMember(member);
      insertMember({ ...member, name: 'Juan Updated' });
      
      const members = queryMembers();
      expect(members).toHaveLength(1);
      expect(members[0].name).toBe('Juan Updated');
    });
  });
  
  describe('message operations', () => {
    it('inserts and queries messages', () => {
      const member: Member = { id: 'member-1', name: 'Juan' };
      const message: Message = {
        id: 'msg-1',
        authorId: 'member-1',
        text: 'Hola mundo',
        timestamp: Date.now()
      };
      
      insertMember(member);
      insertMessage(message);
      
      const messages = queryMessages();
      expect(messages).toHaveLength(1);
      expect(messages[0].text).toBe('Hola mundo');
    });
    
    it('queries messages by author', () => {
      insertMember({ id: 'm1', name: 'Juan' });
      insertMember({ id: 'm2', name: 'María' });
      insertMessage({ id: 'msg1', authorId: 'm1', text: 'Msg Juan', timestamp: 1 });
      insertMessage({ id: 'msg2', authorId: 'm2', text: 'Msg María', timestamp: 2 });
      
      const messages = queryMessages({ authorId: 'm1' });
      expect(messages).toHaveLength(1);
      expect(messages[0].text).toBe('Msg Juan');
    });
    
    it('queries messages by author name', () => {
      insertMember({ id: 'm1', name: 'Juan Pérez' });
      insertMember({ id: 'm2', name: 'María García' });
      insertMessage({ id: 'msg1', authorId: 'm1', text: 'Msg Juan', timestamp: 1 });
      insertMessage({ id: 'msg2', authorId: 'm2', text: 'Msg María', timestamp: 2 });
      
      const messages = queryMessages({ authorName: 'Juan' });
      expect(messages).toHaveLength(1);
      expect(messages[0].text).toBe('Msg Juan');
    });
    
    it('queries messages by timestamp range', () => {
      insertMember({ id: 'm1', name: 'Juan' });
      insertMessage({ id: 'msg1', authorId: 'm1', text: 'Msg 1', timestamp: 100 });
      insertMessage({ id: 'msg2', authorId: 'm1', text: 'Msg 2', timestamp: 200 });
      insertMessage({ id: 'msg3', authorId: 'm1', text: 'Msg 3', timestamp: 300 });
      
      const messages = queryMessages({ fromTimestamp: 150, toTimestamp: 250 });
      expect(messages).toHaveLength(1);
      expect(messages[0].text).toBe('Msg 2');
    });
    
    it('limits query results', () => {
      insertMember({ id: 'm1', name: 'Juan' });
      for (let i = 0; i < 10; i++) {
        insertMessage({ id: `msg${i}`, authorId: 'm1', text: `Msg ${i}`, timestamp: i });
      }
      
      const messages = queryMessages({ limit: 5 });
      expect(messages).toHaveLength(5);
    });
    
    it('returns messages in chronological order', () => {
      insertMember({ id: 'm1', name: 'Juan' });
      insertMessage({ id: 'msg3', authorId: 'm1', text: 'Third', timestamp: 300 });
      insertMessage({ id: 'msg1', authorId: 'm1', text: 'First', timestamp: 100 });
      insertMessage({ id: 'msg2', authorId: 'm1', text: 'Second', timestamp: 200 });
      
      const messages = queryMessages();
      expect(messages[0].text).toBe('First');
      expect(messages[1].text).toBe('Second');
      expect(messages[2].text).toBe('Third');
    });
  });
  
  describe('batch operations', () => {
    it('inserts batch of members and messages', () => {
      const members: Member[] = [
        { id: 'm1', name: 'Juan' },
        { id: 'm2', name: 'María' }
      ];
      const messages: Message[] = [
        { id: 'msg1', authorId: 'm1', text: 'Hola', timestamp: 1 },
        { id: 'msg2', authorId: 'm2', text: 'Hola Juan', timestamp: 2 }
      ];
      
      insertBatch(members, messages);
      
      const stats = getStats();
      expect(stats.memberCount).toBe(2);
      expect(stats.messageCount).toBe(2);
    });
  });
  
  describe('stats', () => {
    it('returns correct stats', () => {
      insertMember({ id: 'm1', name: 'Juan' });
      insertMember({ id: 'm2', name: 'María' });
      insertMessage({ id: 'msg1', authorId: 'm1', text: 'Msg 1', timestamp: 1 });
      insertMessage({ id: 'msg2', authorId: 'm1', text: 'Msg 2', timestamp: 2 });
      insertMessage({ id: 'msg3', authorId: 'm2', text: 'Msg 3', timestamp: 3 });
      
      const stats = getStats();
      expect(stats.memberCount).toBe(2);
      expect(stats.messageCount).toBe(3);
    });
    
    it('returns zero stats for empty database', () => {
      const stats = getStats();
      expect(stats.memberCount).toBe(0);
      expect(stats.messageCount).toBe(0);
    });
  });
});
