/**
 * RCC-ORG Metrics Tests
 */

import { generateMetricsReport, formatReportConsole, formatReportMarkdown } from '../../org/metrics';
import { Member, Message } from '../../org/types';

describe('Metrics', () => {
  const members: Member[] = [
    { id: 'm1', name: 'Juan' },
    { id: 'm2', name: 'María' },
    { id: 'm3', name: 'Carlos' }
  ];
  
  const createMessage = (
    id: string, 
    authorId: string, 
    text: string, 
    timestamp: number
  ): Message => ({ id, authorId, text, timestamp });
  
  describe('generateMetricsReport', () => {
    it('generates report for empty data', () => {
      const report = generateMetricsReport([], []);
      
      expect(report.channel.totalMessages).toBe(0);
      expect(report.channel.totalMembers).toBe(0);
      expect(report.users).toHaveLength(0);
    });
    
    it('calculates user message count', () => {
      const messages: Message[] = [
        createMessage('1', 'm1', 'Hola', 1000),
        createMessage('2', 'm1', 'Cómo estás', 2000),
        createMessage('3', 'm2', 'Bien', 3000)
      ];
      
      const report = generateMetricsReport(members, messages);
      
      const juan = report.users.find(u => u.userName === 'Juan');
      const maria = report.users.find(u => u.userName === 'María');
      
      expect(juan?.messageCount).toBe(2);
      expect(maria?.messageCount).toBe(1);
    });
    
    it('calculates word count', () => {
      const messages: Message[] = [
        createMessage('1', 'm1', 'Hola mundo cruel', 1000),
        createMessage('2', 'm1', 'Adiós', 2000)
      ];
      
      const report = generateMetricsReport(members, messages);
      const juan = report.users.find(u => u.userName === 'Juan');
      
      expect(juan?.wordCount).toBe(4); // 3 + 1
      expect(juan?.avgWordsPerMessage).toBe(2);
    });
    
    it('calculates active days', () => {
      const day1 = new Date('2024-12-20T10:00:00').getTime();
      const day2 = new Date('2024-12-21T10:00:00').getTime();
      const day3 = new Date('2024-12-22T10:00:00').getTime();
      
      const messages: Message[] = [
        createMessage('1', 'm1', 'Msg 1', day1),
        createMessage('2', 'm1', 'Msg 2', day1 + 3600000), // same day
        createMessage('3', 'm1', 'Msg 3', day2),
        createMessage('4', 'm1', 'Msg 4', day3)
      ];
      
      const report = generateMetricsReport(members, messages);
      const juan = report.users.find(u => u.userName === 'Juan');
      
      expect(juan?.activeDays).toBe(3);
    });
    
    it('calculates peak hour', () => {
      const base = new Date('2024-12-20T00:00:00').getTime();
      const hour14 = base + 14 * 3600000;
      const hour15 = base + 15 * 3600000;
      
      const messages: Message[] = [
        createMessage('1', 'm1', 'Msg', hour14),
        createMessage('2', 'm1', 'Msg', hour14 + 60000),
        createMessage('3', 'm1', 'Msg', hour14 + 120000),
        createMessage('4', 'm1', 'Msg', hour15)
      ];
      
      const report = generateMetricsReport(members, messages);
      const juan = report.users.find(u => u.userName === 'Juan');
      
      expect(juan?.peakHour).toBe(14);
    });
    
    it('calculates intensity from analyzer', () => {
      const messages: Message[] = [
        createMessage('1', 'm1', 'hola todo tranquilo', 1000),
        createMessage('2', 'm1', 'ESTO ES URGENTE!!!', 2000)
      ];
      
      const report = generateMetricsReport(members, messages);
      const juan = report.users.find(u => u.userName === 'Juan');
      
      expect(juan?.tenseMessageCount).toBeGreaterThan(0);
      expect(juan?.avgIntensity).toBeGreaterThan(0);
    });
    
    it('calculates channel metrics', () => {
      const messages: Message[] = [
        createMessage('1', 'm1', 'Msg', 1000),
        createMessage('2', 'm2', 'Msg', 2000),
        createMessage('3', 'm1', 'Msg', 3000)
      ];
      
      const report = generateMetricsReport(members, messages);
      
      expect(report.channel.totalMessages).toBe(3);
      expect(report.channel.totalMembers).toBe(3);
      expect(report.channel.mostActiveUser).toBe('Juan');
    });
    
    it('sorts users by message count descending', () => {
      const messages: Message[] = [
        createMessage('1', 'm1', 'Msg', 1000),
        createMessage('2', 'm2', 'Msg', 2000),
        createMessage('3', 'm2', 'Msg', 3000),
        createMessage('4', 'm2', 'Msg', 4000),
        createMessage('5', 'm3', 'Msg', 5000),
        createMessage('6', 'm3', 'Msg', 6000)
      ];
      
      const report = generateMetricsReport(members, messages);
      
      expect(report.users[0].userName).toBe('María'); // 3 msgs
      expect(report.users[1].userName).toBe('Carlos'); // 2 msgs
      expect(report.users[2].userName).toBe('Juan'); // 1 msg
    });
  });
  
  describe('formatReportConsole', () => {
    it('formats report for console', () => {
      const messages: Message[] = [
        createMessage('1', 'm1', 'Hola', 1000)
      ];
      
      const report = generateMetricsReport(members, messages);
      const output = formatReportConsole(report);
      
      expect(output).toContain('RCC METRICS REPORT');
      expect(output).toContain('Juan');
      expect(output).toContain('Mensajes totales');
    });
  });
  
  describe('formatReportMarkdown', () => {
    it('formats report as markdown', () => {
      const messages: Message[] = [
        createMessage('1', 'm1', 'Hola', 1000)
      ];
      
      const report = generateMetricsReport(members, messages);
      const output = formatReportMarkdown(report);
      
      expect(output).toContain('# RCC Metrics Report');
      expect(output).toContain('| Usuario |');
      expect(output).toContain('Juan');
    });
  });
});
