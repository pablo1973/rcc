/**
 * RCC-ORG CLI Query
 * FASE 1 - Consultar mensajes de SQLite
 * 
 * Uso: 
 *   npx ts-node src/cli/query.ts <db> --author "Juan"
 *   npx ts-node src/cli/query.ts <db> --from "2024-12-24" --to "2024-12-25"
 *   npx ts-node src/cli/query.ts <db> --members
 */

import * as fs from 'fs';
import { initDatabase, queryMessages, queryMembers, getStats, closeDatabase } from '../org/storage';

async function main() {
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    console.error('Uso: npx ts-node src/cli/query.ts <db> [opciones]');
    console.error('');
    console.error('Opciones:');
    console.error('  --author "Nombre"    Filtrar por autor');
    console.error('  --from "YYYY-MM-DD"  Desde fecha');
    console.error('  --to "YYYY-MM-DD"    Hasta fecha');
    console.error('  --limit N            Limitar resultados');
    console.error('  --members            Listar participantes');
    console.error('  --stats              Mostrar estadísticas');
    process.exit(1);
  }
  
  const dbPath = args[0];
  
  if (!fs.existsSync(dbPath)) {
    console.error(`Error: Base de datos no encontrada: ${dbPath}`);
    process.exit(1);
  }
  
  // Parse args
  let author: string | undefined;
  let fromDate: string | undefined;
  let toDate: string | undefined;
  let limit: number | undefined;
  let showMembers = false;
  let showStats = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--author':
        author = args[++i];
        break;
      case '--from':
        fromDate = args[++i];
        break;
      case '--to':
        toDate = args[++i];
        break;
      case '--limit':
        limit = parseInt(args[++i]);
        break;
      case '--members':
        showMembers = true;
        break;
      case '--stats':
        showStats = true;
        break;
    }
  }
  
  await initDatabase(dbPath);
  
  if (showStats) {
    const stats = getStats();
    console.log(`\n📊 Estadísticas`);
    console.log(`─────────────────────────────────`);
    console.log(`Participantes: ${stats.memberCount}`);
    console.log(`Mensajes:      ${stats.messageCount}`);
    console.log(`─────────────────────────────────\n`);
    closeDatabase();
    return;
  }
  
  if (showMembers) {
    const members = queryMembers();
    console.log(`\n👥 Participantes (${members.length})`);
    console.log(`─────────────────────────────────`);
    members.forEach(m => console.log(`  ${m.id.substring(0, 8)}  ${m.name}`));
    console.log(`─────────────────────────────────\n`);
    closeDatabase();
    return;
  }
  
  // Query messages
  const options: any = {};
  
  if (author) {
    options.authorName = author;
  }
  
  if (fromDate) {
    // Parse como UTC inicio del día
    const [year, month, day] = fromDate.split('-').map(Number);
    options.fromTimestamp = Date.UTC(year, month - 1, day, 0, 0, 0, 0);
  }
  
  if (toDate) {
    // Parse como UTC fin del día (23:59:59.999)
    const [year, month, day] = toDate.split('-').map(Number);
    options.toTimestamp = Date.UTC(year, month - 1, day, 23, 59, 59, 999);
  }
  
  if (limit) {
    options.limit = limit;
  }
  
  const messages = queryMessages(options);
  const members = queryMembers();
  const memberMap = new Map(members.map(m => [m.id, m.name]));
  
  console.log(`\n📨 Mensajes (${messages.length})`);
  console.log(`─────────────────────────────────`);
  
  messages.forEach(m => {
    const date = new Date(m.timestamp);
    const dateStr = date.toLocaleDateString('es-AR');
    const timeStr = date.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' });
    const authorName = memberMap.get(m.authorId) || 'Unknown';
    const preview = m.text.substring(0, 60) + (m.text.length > 60 ? '...' : '');
    console.log(`[${dateStr} ${timeStr}] ${authorName}: ${preview}`);
  });
  
  console.log(`─────────────────────────────────\n`);
  
  closeDatabase();
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
