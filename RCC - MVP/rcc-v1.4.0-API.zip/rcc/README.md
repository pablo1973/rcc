# RCC - Regulador Cognitivo Conversacional

## Overview
Pipeline determinístico para regulación de tono e intención conversacional.

## Scope
- Input → Analyzer → Regulator → Output
- Estados: CALM | NEUTRAL | TENSE
- Canales MVP: CLI, Slack

## Status
- v1.0.0-DAY1: Baseline & Contratos
