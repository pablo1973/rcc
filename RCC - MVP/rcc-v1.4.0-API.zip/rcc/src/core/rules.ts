import { State } from "./states";

/**
 * Aplica reglas de transformación según estado
 * TENSE: suaviza mayúsculas y puntuación excesiva
 */
export function applyRules(text: string, state: State): string {
  switch (state) {
    case "CALM":
      return text;
    case "NEUTRAL":
      return text;
    case "TENSE":
      return softenText(text);
    default:
      return text;
  }
}

/**
 * Suaviza texto tenso:
 * - Convierte MAYÚSCULAS a minúsculas (excepto inicio de oración)
 * - Reduce múltiples signos de exclamación/interrogación a uno
 */
function softenText(text: string): string {
  let result = text;
  
  // Reducir múltiples ! o ? a uno solo
  result = result.replace(/!{2,}/g, '!');
  result = result.replace(/\?{2,}/g, '?');
  result = result.replace(/!\?+|!\?+/g, '?');
  
  // Si más del 50% es mayúscula, convertir a sentence case
  const upperCount = (result.match(/[A-Z]/g) || []).length;
  const letterCount = (result.match(/[a-zA-Z]/g) || []).length;
  
  if (letterCount > 0 && upperCount / letterCount > 0.5) {
    result = result.toLowerCase();
    // Capitalizar inicio de oraciones
    result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_, pre, char) => 
      pre + char.toUpperCase()
    );
  }
  
  return result;
}
