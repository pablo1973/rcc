/**
 * RCC Diagnose CLI
 * FASE 2 MVP - Según SPEC exacta
 * 
 * Uso:
 *   npm run diagnose -- --db <path.sqlite> [opciones]
 *   npm run diagnose -- --chat <chat.txt> --outdb <path.sqlite> [opciones]
 * 
 * Exit codes:
 *   0 ok
 *   2 bad args
 *   3 no data found
 */

import * as fs from 'fs';
import { parseWhatsAppExport } from '../org/parser';
import { initDatabase, insertBatch, saveDatabase, queryMessages, queryMembers, closeDatabase } from '../org/storage';
import { generateDiagnoseReport, formatDiagnoseText, formatDiagnoseMd, formatDiagnoseJson } from '../org/diagnose';
import { DiagnoseOptions } from '../org/diagnose.types';

interface CliArgs {
  db?: string;
  chat?: string;
  outdb?: string;
  from?: string;
  to?: string;
  user?: string;
  top: number;
  examples: number;
  format: 'text' | 'md' | 'json';
  out?: string;
  minWords: number;
  includeRegulated: boolean;
}

function parseArgs(args: string[]): CliArgs | null {
  const result: CliArgs = {
    top: 3,
    examples: 3,
    format: 'text',
    minWords: 3,
    includeRegulated: true
  };
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--db':
        result.db = args[++i];
        break;
      case '--chat':
        result.chat = args[++i];
        break;
      case '--outdb':
        result.outdb = args[++i];
        break;
      case '--from':
        result.from = args[++i];
        break;
      case '--to':
        result.to = args[++i];
        break;
      case '--user':
        result.user = args[++i];
        break;
      case '--top':
        result.top = parseInt(args[++i]) || 3;
        break;
      case '--examples':
        result.examples = parseInt(args[++i]) || 3;
        break;
      case '--format':
        const fmt = args[++i];
        if (fmt === 'text' || fmt === 'md' || fmt === 'json') {
          result.format = fmt;
        }
        break;
      case '--out':
        result.out = args[++i];
        break;
      case '--min-words':
        result.minWords = parseInt(args[++i]) || 3;
        break;
      case '--include-regulated':
        const val = args[++i];
        result.includeRegulated = val !== 'false';
        break;
    }
  }
  
  return result;
}

function printUsage(): void {
  console.error(`
RCC Diagnose - FASE 2 MVP

Uso:
  npm run diagnose -- --db <path.sqlite> [opciones]
  npm run diagnose -- --chat <chat.txt> --outdb <path.sqlite> [opciones]

Opciones:
  --db <file>              Base de datos SQLite (req si no hay --chat)
  --chat <file>            Archivo chat.txt (req si no hay --db)
  --outdb <file>           DB de salida (req si usás --chat)
  --from YYYY-MM-DD        Filtrar desde fecha
  --to YYYY-MM-DD          Filtrar hasta fecha (inclusivo)
  --user "<name>"          Filtrar a un usuario
  --top N                  Top N usuarios por fricción (default 3)
  --examples N             Cantidad de ejemplos (default 3)
  --format text|md|json    Formato de salida (default text)
  --out <file>             Archivo de salida (default stdout)
  --min-words N            Ignorar mensajes con menos de N palabras (default 3)
  --include-regulated      Incluir reescritura (default true)

Exit codes:
  0  ok
  2  bad args
  3  no data found
`);
}

async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  
  if (!args) {
    printUsage();
    process.exit(2);
  }
  
  // Validar args
  if (!args.db && !args.chat) {
    console.error('Error: Requiere --db o --chat');
    printUsage();
    process.exit(2);
  }
  
  if (args.chat && !args.outdb) {
    console.error('Error: --chat requiere --outdb');
    printUsage();
    process.exit(2);
  }
  
  let dbPath: string;
  
  // Si hay --chat, importar primero
  if (args.chat) {
    if (!fs.existsSync(args.chat)) {
      console.error(`Error: Archivo no encontrado: ${args.chat}`);
      process.exit(2);
    }
    
    console.error(`Importando ${args.chat}...`);
    
    const content = fs.readFileSync(args.chat, 'utf-8');
    const parseResult = parseWhatsAppExport(content);
    
    await initDatabase();
    insertBatch(parseResult.members, parseResult.messages);
    saveDatabase(args.outdb!);
    closeDatabase();
    
    console.error(`Importado: ${parseResult.members.length} usuarios, ${parseResult.messages.length} mensajes`);
    
    dbPath = args.outdb!;
  } else {
    if (!fs.existsSync(args.db!)) {
      console.error(`Error: Base de datos no encontrada: ${args.db}`);
      process.exit(2);
    }
    dbPath = args.db!;
  }
  
  // Cargar datos
  await initDatabase(dbPath);
  const members = queryMembers();
  const messages = queryMessages();
  closeDatabase();
  
  if (messages.length === 0) {
    console.error('Error: No hay datos para analizar');
    process.exit(3);
  }
  
  // Generar diagnóstico
  const options: DiagnoseOptions = {
    from: args.from,
    to: args.to,
    user: args.user,
    top: args.top,
    examples: args.examples,
    minWords: args.minWords,
    includeRegulated: args.includeRegulated
  };
  
  const report = generateDiagnoseReport(members, messages, options);
  
  // Verificar que hay datos después de filtrar
  if (report.meta.messages === 0) {
    console.error('Error: No hay mensajes que cumplan los filtros');
    process.exit(3);
  }
  
  // Formatear output
  let output: string;
  switch (args.format) {
    case 'md':
      output = formatDiagnoseMd(report);
      break;
    case 'json':
      output = formatDiagnoseJson(report);
      break;
    default:
      output = formatDiagnoseText(report);
  }
  
  // Escribir output
  if (args.out) {
    fs.writeFileSync(args.out, output, 'utf-8');
    console.error(`Reporte guardado en: ${args.out}`);
  } else {
    console.log(output);
  }
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(2);
});
