/**
 * RCC-ORG WhatsApp Parser
 * FASE 1 - Mínimo viable
 * 
 * Formato soportado: DD/MM/YYYY, HH:MM - Author: Message
 * Encoding: UTF-8
 * Timezone: UTC-3 (Argentina) hardcoded
 */

import { Member, Message, ParseResult } from './types';

// Regex para formato WhatsApp Argentina
// DD/MM/YYYY, HH:MM - Author: Message
const LINE_REGEX = /^(\d{1,2})\/(\d{1,2})\/(\d{4}), (\d{1,2}):(\d{2}) - ([^:]+): (.+)$/;

// Mensajes de sistema a ignorar
const SYSTEM_PATTERNS = [
  /creó el grupo/i,
  /cambió el ícono/i,
  /cambió la descripción/i,
  /añadió a/i,
  /eliminó a/i,
  /salió del grupo/i,
  /Los mensajes y las llamadas/i,
  /cifrado de extremo a extremo/i,
  /<Multimedia omitido>/i,
  /Este mensaje fue eliminado/i,
  /Se eliminó este mensaje/i,
];

function isSystemMessage(text: string): boolean {
  return SYSTEM_PATTERNS.some(pattern => pattern.test(text));
}

// Contador global para IDs únicos dentro de una sesión de parseo
let idCounter = 0;

function generateId(prefix: string): string {
  // Formato: prefix_timestamp_contador
  // Garantiza unicidad incluso si se reimporta
  idCounter++;
  return `${prefix}_${Date.now()}_${idCounter}`;
}

// Reset del contador (para tests)
export function resetIdCounter(): void {
  idCounter = 0;
}

function parseTimestamp(
  day: string, 
  month: string, 
  year: string, 
  hour: string, 
  minute: string
): number {
  // Almacenar timestamp tal cual aparece en el chat
  // Sin conversión de timezone para UX intuitiva
  // Si el chat dice "21/12 14:30", el usuario espera encontrarlo
  // buscando "día 21", no "día 21 o 22 dependiendo de UTC"
  //
  // Contrato: timestamp = fecha/hora del chat interpretada como UTC
  
  return Date.UTC(
    parseInt(year),
    parseInt(month) - 1,  // JS months are 0-indexed
    parseInt(day),
    parseInt(hour),
    parseInt(minute),
    0,
    0
  );
}

export function parseWhatsAppExport(content: string): ParseResult {
  const lines = content.split('\n');
  const members: Map<string, Member> = new Map();
  const messages: Message[] = [];
  const errors: string[] = [];
  
  let currentMessage: { author: string; text: string; timestamp: number } | null = null;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // Skip empty lines
    if (!line) continue;
    
    const match = line.match(LINE_REGEX);
    
    if (match) {
      // Si hay mensaje pendiente, guardarlo
      if (currentMessage && !isSystemMessage(currentMessage.text)) {
        // Get or create member
        let member = members.get(currentMessage.author);
        if (!member) {
          member = { id: generateId('m'), name: currentMessage.author };
          members.set(currentMessage.author, member);
        }
        
        messages.push({
          id: generateId('msg'),
          authorId: member.id,
          text: currentMessage.text,
          timestamp: currentMessage.timestamp
        });
      }
      
      // Nuevo mensaje
      const [, day, month, year, hour, minute, author, text] = match;
      currentMessage = {
        author: author.trim(),
        text: text.trim(),
        timestamp: parseTimestamp(day, month, year, hour, minute)
      };
    } else if (currentMessage) {
      // Línea de continuación (mensaje multilínea)
      currentMessage.text += '\n' + line;
    } else {
      // Línea que no matchea y no hay mensaje previo
      if (line.length > 0 && !isSystemMessage(line)) {
        errors.push(`Línea ${i + 1}: ${line.substring(0, 50)}...`);
      }
    }
  }
  
  // Guardar último mensaje
  if (currentMessage && !isSystemMessage(currentMessage.text)) {
    let member = members.get(currentMessage.author);
    if (!member) {
      member = { id: generateId('m'), name: currentMessage.author };
      members.set(currentMessage.author, member);
    }
    
    messages.push({
      id: generateId('msg'),
      authorId: member.id,
      text: currentMessage.text,
      timestamp: currentMessage.timestamp
    });
  }
  
  return {
    members: Array.from(members.values()),
    messages,
    errors
  };
}
