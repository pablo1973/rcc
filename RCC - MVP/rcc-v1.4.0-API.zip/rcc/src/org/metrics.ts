/**
 * RCC-ORG Metrics Calculator
 * FASE 2 - Métricas por usuario
 */

import { Message, Member } from './types';
import { UserMetrics, ChannelMetrics, MetricsReport } from './metrics.types';
import { analyze } from '../core/analyzer';

/**
 * Calcula métricas para un usuario
 */
function computeUserMetrics(
  member: Member,
  messages: Message[]
): UserMetrics {
  const userMessages = messages.filter(m => m.authorId === member.id);
  
  if (userMessages.length === 0) {
    return {
      userId: member.id,
      userName: member.name,
      messageCount: 0,
      wordCount: 0,
      avgWordsPerMessage: 0,
      firstMessageAt: 0,
      lastMessageAt: 0,
      activeDays: 0,
      peakHour: 0,
      hourDistribution: new Array(24).fill(0),
      avgIntensity: 0,
      tenseMessageCount: 0,
      calmMessageCount: 0
    };
  }
  
  // Volumen
  const wordCounts = userMessages.map(m => 
    m.text.split(/\s+/).filter(w => w.length > 0).length
  );
  const totalWords = wordCounts.reduce((a, b) => a + b, 0);
  
  // Timing
  const timestamps = userMessages.map(m => m.timestamp).sort((a, b) => a - b);
  const uniqueDays = new Set(
    userMessages.map(m => {
      const d = new Date(m.timestamp);
      return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    })
  );
  
  // Distribución por hora
  const hourDistribution = new Array(24).fill(0);
  userMessages.forEach(m => {
    const hour = new Date(m.timestamp).getHours();
    hourDistribution[hour]++;
  });
  
  const peakHour = hourDistribution.indexOf(Math.max(...hourDistribution));
  
  // Intensidad usando core analyzer
  let totalIntensity = 0;
  let tenseCount = 0;
  let calmCount = 0;
  
  userMessages.forEach(m => {
    const analysis = analyze(m.text);
    totalIntensity += analysis.score;
    if (analysis.state === 'TENSE') tenseCount++;
    if (analysis.state === 'CALM') calmCount++;
  });
  
  return {
    userId: member.id,
    userName: member.name,
    messageCount: userMessages.length,
    wordCount: totalWords,
    avgWordsPerMessage: Math.round((totalWords / userMessages.length) * 10) / 10,
    firstMessageAt: timestamps[0],
    lastMessageAt: timestamps[timestamps.length - 1],
    activeDays: uniqueDays.size,
    peakHour,
    hourDistribution,
    avgIntensity: Math.round((totalIntensity / userMessages.length) * 1000) / 1000,
    tenseMessageCount: tenseCount,
    calmMessageCount: calmCount
  };
}

/**
 * Calcula métricas del canal
 */
function computeChannelMetrics(
  members: Member[],
  messages: Message[],
  userMetrics: UserMetrics[]
): ChannelMetrics {
  if (messages.length === 0) {
    return {
      totalMessages: 0,
      totalMembers: members.length,
      dateRange: { from: 0, to: 0 },
      avgMessagesPerDay: 0,
      mostActiveUser: '',
      leastActiveUser: ''
    };
  }
  
  const timestamps = messages.map(m => m.timestamp).sort((a, b) => a - b);
  const from = timestamps[0];
  const to = timestamps[timestamps.length - 1];
  
  const daysDiff = Math.max(1, Math.ceil((to - from) / (1000 * 60 * 60 * 24)));
  
  const sortedByActivity = [...userMetrics]
    .filter(u => u.messageCount > 0)
    .sort((a, b) => b.messageCount - a.messageCount);
  
  return {
    totalMessages: messages.length,
    totalMembers: members.length,
    dateRange: { from, to },
    avgMessagesPerDay: Math.round((messages.length / daysDiff) * 10) / 10,
    mostActiveUser: sortedByActivity[0]?.userName || '',
    leastActiveUser: sortedByActivity[sortedByActivity.length - 1]?.userName || ''
  };
}

/**
 * Genera reporte completo de métricas
 */
export function generateMetricsReport(
  members: Member[],
  messages: Message[]
): MetricsReport {
  const userMetrics = members.map(m => computeUserMetrics(m, messages));
  const channelMetrics = computeChannelMetrics(members, messages, userMetrics);
  
  return {
    channel: channelMetrics,
    users: userMetrics.sort((a, b) => b.messageCount - a.messageCount),
    generatedAt: Date.now()
  };
}

/**
 * Formatea el reporte para consola
 */
export function formatReportConsole(report: MetricsReport): string {
  const lines: string[] = [];
  
  const fromDate = report.channel.dateRange.from 
    ? new Date(report.channel.dateRange.from).toLocaleDateString('es-AR')
    : 'N/A';
  const toDate = report.channel.dateRange.to
    ? new Date(report.channel.dateRange.to).toLocaleDateString('es-AR')
    : 'N/A';
  
  lines.push('');
  lines.push('═══════════════════════════════════════════════════════════════');
  lines.push('                    📊 RCC METRICS REPORT');
  lines.push('═══════════════════════════════════════════════════════════════');
  lines.push('');
  lines.push('📈 RESUMEN DEL CANAL');
  lines.push('───────────────────────────────────────────────────────────────');
  lines.push(`   Mensajes totales:    ${report.channel.totalMessages}`);
  lines.push(`   Participantes:       ${report.channel.totalMembers}`);
  lines.push(`   Período:             ${fromDate} - ${toDate}`);
  lines.push(`   Promedio/día:        ${report.channel.avgMessagesPerDay} mensajes`);
  lines.push(`   Más activo:          ${report.channel.mostActiveUser}`);
  lines.push(`   Menos activo:        ${report.channel.leastActiveUser}`);
  lines.push('');
  lines.push('👥 MÉTRICAS POR USUARIO');
  lines.push('───────────────────────────────────────────────────────────────');
  
  for (const user of report.users) {
    if (user.messageCount === 0) continue;
    
    const firstDate = new Date(user.firstMessageAt).toLocaleDateString('es-AR');
    const lastDate = new Date(user.lastMessageAt).toLocaleDateString('es-AR');
    const intensityBar = '█'.repeat(Math.round(user.avgIntensity * 10)) + 
                         '░'.repeat(10 - Math.round(user.avgIntensity * 10));
    
    lines.push('');
    lines.push(`   📌 ${user.userName}`);
    lines.push(`      Mensajes:         ${user.messageCount}`);
    lines.push(`      Palabras:         ${user.wordCount} (${user.avgWordsPerMessage} prom/msg)`);
    lines.push(`      Días activos:     ${user.activeDays}`);
    lines.push(`      Hora pico:        ${user.peakHour}:00`);
    lines.push(`      Período:          ${firstDate} - ${lastDate}`);
    lines.push(`      Intensidad:       [${intensityBar}] ${(user.avgIntensity * 100).toFixed(1)}%`);
    lines.push(`      Tensión:          ${user.tenseMessageCount} msgs tensos, ${user.calmMessageCount} calmos`);
  }
  
  lines.push('');
  lines.push('═══════════════════════════════════════════════════════════════');
  lines.push(`   Generado: ${new Date(report.generatedAt).toLocaleString('es-AR')}`);
  lines.push('═══════════════════════════════════════════════════════════════');
  lines.push('');
  
  return lines.join('\n');
}

/**
 * Formatea el reporte como Markdown
 */
export function formatReportMarkdown(report: MetricsReport): string {
  const lines: string[] = [];
  
  const fromDate = report.channel.dateRange.from 
    ? new Date(report.channel.dateRange.from).toLocaleDateString('es-AR')
    : 'N/A';
  const toDate = report.channel.dateRange.to
    ? new Date(report.channel.dateRange.to).toLocaleDateString('es-AR')
    : 'N/A';
  
  lines.push('# RCC Metrics Report');
  lines.push('');
  lines.push('## Resumen del Canal');
  lines.push('');
  lines.push('| Métrica | Valor |');
  lines.push('|---------|-------|');
  lines.push(`| Mensajes totales | ${report.channel.totalMessages} |`);
  lines.push(`| Participantes | ${report.channel.totalMembers} |`);
  lines.push(`| Período | ${fromDate} - ${toDate} |`);
  lines.push(`| Promedio/día | ${report.channel.avgMessagesPerDay} |`);
  lines.push(`| Más activo | ${report.channel.mostActiveUser} |`);
  lines.push(`| Menos activo | ${report.channel.leastActiveUser} |`);
  lines.push('');
  lines.push('## Métricas por Usuario');
  lines.push('');
  lines.push('| Usuario | Msgs | Palabras | Prom/Msg | Días | Hora Pico | Intensidad | Tensos |');
  lines.push('|---------|------|----------|----------|------|-----------|------------|--------|');
  
  for (const user of report.users) {
    if (user.messageCount === 0) continue;
    lines.push(
      `| ${user.userName} | ${user.messageCount} | ${user.wordCount} | ${user.avgWordsPerMessage} | ${user.activeDays} | ${user.peakHour}:00 | ${(user.avgIntensity * 100).toFixed(1)}% | ${user.tenseMessageCount} |`
    );
  }
  
  lines.push('');
  lines.push('---');
  lines.push(`*Generado: ${new Date(report.generatedAt).toLocaleString('es-AR')}*`);
  
  return lines.join('\n');
}
