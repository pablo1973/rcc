/**
 * RCC API Server
 * Backend compartido para Android + CLI
 */

import http from 'http';
import { analyze } from './core/analyzer';
import { regulate } from './core/regulator';

const PORT = process.env.PORT || 3000;

interface AnalyzeRequest {
  text: string;
}

interface TransformRequest {
  text: string;
  mode?: 'SUAVE' | 'PROFESIONAL' | 'EMPATICO';
}

interface AnalyzeResponse {
  state: string;
  score: number;
  reason: string;
}

interface TransformResponse {
  original: string;
  transformed: string;
  state: string;
  score: number;
  intent: string;
}

function detectIntent(text: string): string {
  const t = text.toLowerCase();
  
  if (['ayuda', 'necesito que', 'no entiendo', 'no sé', 'no se', 'me podés', 'me podes']
      .some(k => t.includes(k))) return 'REQUEST_HELP';
  
  if (['esto está mal', 'esto esta mal', 'no funciona', 'desastre', 'malísimo', 'malisimo']
      .some(k => t.includes(k))) return 'COMPLAINT';
  
  if (['ya hice', 'te aviso', 'te cuento', 'actualizo', 'ya lo resolví', 'ya lo resolvi']
      .some(k => t.includes(k))) return 'STATUS_UPDATE';
  
  if (['tenes que', 'tenés que', 'tienes que', 'debes', 'hacé', 'hace esto', 'haga esto']
      .some(k => t.includes(k))) return 'INSTRUCTION';
  
  if (['buen día', 'buen dia', 'como andas', 'cómo andás', 'jaja', 'jajaja']
      .some(k => t.includes(k))) return 'SMALL_TALK';
  
  return 'NEUTRAL';
}

function getEncabezado(mode: string, state: string): string {
  switch (mode) {
    case 'SUAVE':
      return state === 'TENSE' 
        ? 'Te lo marco con calma para que podamos verlo bien.\n\n'
        : '';
    case 'PROFESIONAL':
      return 'Resumen claro y profesional:\n';
    case 'EMPATICO':
      return 'Estoy con vos, vamos paso por paso.\n\n';
    default:
      return '';
  }
}

function getFraseIntent(intent: string): string {
  switch (intent) {
    case 'REQUEST_HELP': return 'Reformula tu pedido de ayuda así se entiende mejor:\n\n';
    case 'COMPLAINT': return 'Te ayudo a plantear el reclamo sin romper la relación:\n\n';
    case 'STATUS_UPDATE': return 'Dejemos clara la actualización de estado:\n\n';
    case 'INSTRUCTION': return 'Lo dejo como pedido claro y respetuoso:\n\n';
    case 'SMALL_TALK': return 'Lo adapté como mensaje de charla tranquila:\n\n';
    default: return '';
  }
}

function handleRequest(req: http.IncomingMessage, res: http.ServerResponse) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = req.url || '/';

  // Health check
  if (url === '/health' && req.method === 'GET') {
    res.writeHead(200);
    res.end(JSON.stringify({ status: 'ok', version: '1.0.0' }));
    return;
  }

  // Solo POST para analyze y transform
  if (req.method !== 'POST') {
    res.writeHead(405);
    res.end(JSON.stringify({ error: 'Method not allowed' }));
    return;
  }

  let body = '';
  req.on('data', chunk => { body += chunk; });
  req.on('end', () => {
    try {
      const data = JSON.parse(body);

      if (url === '/analyze') {
        const { text } = data as AnalyzeRequest;
        if (!text) {
          res.writeHead(400);
          res.end(JSON.stringify({ error: 'Missing text field' }));
          return;
        }

        const analysis = analyze(text);
        const response: AnalyzeResponse = {
          state: analysis.state,
          score: analysis.score,
          reason: analysis.reason
        };

        res.writeHead(200);
        res.end(JSON.stringify(response));
        return;
      }

      if (url === '/transform') {
        const { text, mode = 'SUAVE' } = data as TransformRequest;
        if (!text) {
          res.writeHead(400);
          res.end(JSON.stringify({ error: 'Missing text field' }));
          return;
        }

        const analysis = analyze(text);
        const regulation = regulate(analysis, text);
        const intent = detectIntent(text);
        
        const encabezado = getEncabezado(mode, analysis.state);
        const fraseIntent = getFraseIntent(intent);
        const transformed = encabezado + fraseIntent + regulation.message;

        const response: TransformResponse = {
          original: text,
          transformed: transformed.trim(),
          state: analysis.state,
          score: analysis.score,
          intent: intent
        };

        res.writeHead(200);
        res.end(JSON.stringify(response));
        return;
      }

      res.writeHead(404);
      res.end(JSON.stringify({ error: 'Not found' }));
    } catch (e) {
      res.writeHead(400);
      res.end(JSON.stringify({ error: 'Invalid JSON' }));
    }
  });
}

const server = http.createServer(handleRequest);

server.listen(PORT, () => {
  console.log(`RCC API running on http://localhost:${PORT}`);
  console.log('Endpoints:');
  console.log('  GET  /health     - Health check');
  console.log('  POST /analyze    - Analyze text');
  console.log('  POST /transform  - Transform text');
});
