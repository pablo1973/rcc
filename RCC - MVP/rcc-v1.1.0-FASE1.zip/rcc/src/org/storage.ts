/**
 * RCC-ORG Storage
 * FASE 1 - SQLite con sql.js
 */

// eslint-disable-next-line @typescript-eslint/no-var-requires
const initSqlJs = require('sql.js');
import * as fs from 'fs';
import { Member, Message } from './types';

type Database = any;

let db: Database | null = null;

export async function initDatabase(dbPath?: string): Promise<void> {
  const SQL = await initSqlJs();
  
  if (dbPath && fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }
  
  // Create tables
  db.run(`
    CREATE TABLE IF NOT EXISTS members (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL
    )
  `);
  
  db.run(`
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      author_id TEXT NOT NULL,
      text TEXT NOT NULL,
      timestamp INTEGER NOT NULL,
      FOREIGN KEY (author_id) REFERENCES members(id)
    )
  `);
  
  // Indexes
  db.run(`CREATE INDEX IF NOT EXISTS idx_messages_author ON messages(author_id)`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_messages_timestamp ON messages(timestamp)`);
}

export function saveDatabase(dbPath: string): void {
  if (!db) throw new Error('Database not initialized');
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

export function insertMember(member: Member): void {
  if (!db) throw new Error('Database not initialized');
  db.run(
    'INSERT OR REPLACE INTO members (id, name) VALUES (?, ?)',
    [member.id, member.name]
  );
}

export function insertMessage(message: Message): void {
  if (!db) throw new Error('Database not initialized');
  db.run(
    'INSERT OR REPLACE INTO messages (id, author_id, text, timestamp) VALUES (?, ?, ?, ?)',
    [message.id, message.authorId, message.text, message.timestamp]
  );
}

export function insertBatch(members: Member[], messages: Message[]): void {
  if (!db) throw new Error('Database not initialized');
  
  db.run('BEGIN TRANSACTION');
  try {
    for (const member of members) {
      insertMember(member);
    }
    for (const message of messages) {
      insertMessage(message);
    }
    db.run('COMMIT');
  } catch (e) {
    db.run('ROLLBACK');
    throw e;
  }
}

export interface QueryOptions {
  authorId?: string;
  authorName?: string;
  fromTimestamp?: number;
  toTimestamp?: number;
  limit?: number;
}

export function queryMessages(options: QueryOptions = {}): Message[] {
  if (!db) throw new Error('Database not initialized');
  
  let sql = `
    SELECT m.id, m.author_id, m.text, m.timestamp
    FROM messages m
  `;
  const conditions: string[] = [];
  const params: (string | number)[] = [];
  
  if (options.authorId) {
    conditions.push('m.author_id = ?');
    params.push(options.authorId);
  }
  
  if (options.authorName) {
    sql = `
      SELECT m.id, m.author_id, m.text, m.timestamp
      FROM messages m
      JOIN members mb ON m.author_id = mb.id
    `;
    conditions.push('mb.name LIKE ?');
    params.push(`%${options.authorName}%`);
  }
  
  if (options.fromTimestamp) {
    conditions.push('m.timestamp >= ?');
    params.push(options.fromTimestamp);
  }
  
  if (options.toTimestamp) {
    conditions.push('m.timestamp <= ?');
    params.push(options.toTimestamp);
  }
  
  if (conditions.length > 0) {
    sql += ' WHERE ' + conditions.join(' AND ');
  }
  
  sql += ' ORDER BY m.timestamp ASC';
  
  if (options.limit) {
    sql += ' LIMIT ?';
    params.push(options.limit);
  }
  
  const results = db.exec(sql, params);
  
  if (results.length === 0) return [];
  
  return results[0].values.map((row: any[]) => ({
    id: row[0] as string,
    authorId: row[1] as string,
    text: row[2] as string,
    timestamp: row[3] as number
  }));
}

export function queryMembers(): Member[] {
  if (!db) throw new Error('Database not initialized');
  
  const results = db.exec('SELECT id, name FROM members ORDER BY name');
  
  if (results.length === 0) return [];
  
  return results[0].values.map((row: any[]) => ({
    id: row[0] as string,
    name: row[1] as string
  }));
}

export function getStats(): { memberCount: number; messageCount: number } {
  if (!db) throw new Error('Database not initialized');
  
  const members = db.exec('SELECT COUNT(*) FROM members');
  const messages = db.exec('SELECT COUNT(*) FROM messages');
  
  return {
    memberCount: members[0]?.values[0]?.[0] as number || 0,
    messageCount: messages[0]?.values[0]?.[0] as number || 0
  };
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}
