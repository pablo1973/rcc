/**
 * RCC-ORG CLI Import
 * FASE 1 - Importar WhatsApp .txt a SQLite
 * 
 * Uso: npx ts-node src/cli/import.ts <chat.txt> [output.db]
 */

import * as fs from 'fs';
import * as path from 'path';
import { parseWhatsAppExport } from '../org/parser';
import { initDatabase, insertBatch, saveDatabase, getStats, closeDatabase } from '../org/storage';

async function main() {
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    console.error('Uso: npx ts-node src/cli/import.ts <chat.txt> [output.db]');
    console.error('');
    console.error('Ejemplo:');
    console.error('  npx ts-node src/cli/import.ts "Chat de WhatsApp.txt" chat.db');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const outputFile = args[1] || 'rcc.db';
  
  // Validar input
  if (!fs.existsSync(inputFile)) {
    console.error(`Error: Archivo no encontrado: ${inputFile}`);
    process.exit(1);
  }
  
  console.log(`\n📱 RCC-ORG Import`);
  console.log(`─────────────────────────────────`);
  console.log(`Input:  ${inputFile}`);
  console.log(`Output: ${outputFile}`);
  console.log(`─────────────────────────────────\n`);
  
  // Leer archivo
  console.log(`📖 Leyendo archivo...`);
  const content = fs.readFileSync(inputFile, 'utf-8');
  const lines = content.split('\n').length;
  console.log(`   ${lines} líneas`);
  
  // Parsear
  console.log(`\n🔍 Parseando mensajes...`);
  const result = parseWhatsAppExport(content);
  console.log(`   ${result.members.length} participantes`);
  console.log(`   ${result.messages.length} mensajes`);
  
  if (result.errors.length > 0) {
    console.log(`   ⚠️  ${result.errors.length} líneas ignoradas`);
    if (result.errors.length <= 5) {
      result.errors.forEach(e => console.log(`      - ${e}`));
    }
  }
  
  // Guardar en SQLite
  console.log(`\n💾 Guardando en SQLite...`);
  await initDatabase();
  insertBatch(result.members, result.messages);
  saveDatabase(outputFile);
  
  const stats = getStats();
  closeDatabase();
  
  // Resumen
  console.log(`\n✅ Import completado`);
  console.log(`─────────────────────────────────`);
  console.log(`Participantes: ${stats.memberCount}`);
  console.log(`Mensajes:      ${stats.messageCount}`);
  console.log(`Archivo:       ${outputFile}`);
  console.log(`─────────────────────────────────\n`);
  
  // Mostrar participantes
  console.log(`👥 Participantes:`);
  result.members.forEach(m => {
    const count = result.messages.filter(msg => msg.authorId === m.id).length;
    console.log(`   - ${m.name} (${count} mensajes)`);
  });
  console.log('');
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
