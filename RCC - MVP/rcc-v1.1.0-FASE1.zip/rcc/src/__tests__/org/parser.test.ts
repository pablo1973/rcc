/**
 * RCC-ORG Parser Tests
 */

import { parseWhatsAppExport } from '../../org/parser';

describe('WhatsApp Parser', () => {
  describe('basic parsing', () => {
    it('parses single message', () => {
      const input = '24/12/2024, 14:35 - Juan Pérez: Hola mundo';
      const result = parseWhatsAppExport(input);
      
      expect(result.members).toHaveLength(1);
      expect(result.members[0].name).toBe('Juan Pérez');
      expect(result.messages).toHaveLength(1);
      expect(result.messages[0].text).toBe('Hola mundo');
    });
    
    it('parses multiple messages from same author', () => {
      const input = `24/12/2024, 14:35 - Juan: Hola
24/12/2024, 14:36 - Juan: Cómo estás`;
      const result = parseWhatsAppExport(input);
      
      expect(result.members).toHaveLength(1);
      expect(result.messages).toHaveLength(2);
    });
    
    it('parses messages from multiple authors', () => {
      const input = `24/12/2024, 14:35 - Juan: Hola
24/12/2024, 14:36 - María: Hola Juan`;
      const result = parseWhatsAppExport(input);
      
      expect(result.members).toHaveLength(2);
      expect(result.messages).toHaveLength(2);
    });
    
    it('handles multiline messages', () => {
      const input = `24/12/2024, 14:35 - Juan: Primera línea
Segunda línea
Tercera línea
24/12/2024, 14:36 - María: Respuesta`;
      const result = parseWhatsAppExport(input);
      
      expect(result.messages).toHaveLength(2);
      expect(result.messages[0].text).toContain('Primera línea');
      expect(result.messages[0].text).toContain('Segunda línea');
      expect(result.messages[0].text).toContain('Tercera línea');
    });
  });
  
  describe('system messages filtering', () => {
    it('ignores multimedia messages', () => {
      const input = `24/12/2024, 14:35 - Juan: <Multimedia omitido>`;
      const result = parseWhatsAppExport(input);
      
      expect(result.messages).toHaveLength(0);
    });
    
    it('ignores group creation messages', () => {
      const input = `24/12/2024, 14:35 - Juan creó el grupo "Test"`;
      const result = parseWhatsAppExport(input);
      
      // This line doesn't match the message format, so no author
      expect(result.messages).toHaveLength(0);
    });
    
    it('ignores deleted messages', () => {
      const input = `24/12/2024, 14:35 - Juan: Se eliminó este mensaje`;
      const result = parseWhatsAppExport(input);
      
      expect(result.messages).toHaveLength(0);
    });
  });
  
  describe('date parsing', () => {
    it('parses date correctly', () => {
      const input = '01/01/2024, 00:00 - Test: Mensaje';
      const result = parseWhatsAppExport(input);
      
      expect(result.messages).toHaveLength(1);
      // Timestamp should be valid
      expect(result.messages[0].timestamp).toBeGreaterThan(0);
    });
    
    it('handles single digit days and months', () => {
      const input = '1/5/2024, 9:05 - Test: Mensaje';
      const result = parseWhatsAppExport(input);
      
      expect(result.messages).toHaveLength(1);
    });
  });
  
  describe('edge cases', () => {
    it('handles empty input', () => {
      const result = parseWhatsAppExport('');
      
      expect(result.members).toHaveLength(0);
      expect(result.messages).toHaveLength(0);
      expect(result.errors).toHaveLength(0);
    });
    
    it('handles input with only empty lines', () => {
      const result = parseWhatsAppExport('\n\n\n');
      
      expect(result.members).toHaveLength(0);
      expect(result.messages).toHaveLength(0);
    });
    
    it('handles messages with colons in text', () => {
      const input = '24/12/2024, 14:35 - Juan: URL: https://example.com';
      const result = parseWhatsAppExport(input);
      
      expect(result.messages).toHaveLength(1);
      expect(result.messages[0].text).toBe('URL: https://example.com');
    });
    
    it('handles unicode and emojis', () => {
      const input = '24/12/2024, 14:35 - Juan: Hola 👋 ¿cómo estás?';
      const result = parseWhatsAppExport(input);
      
      expect(result.messages).toHaveLength(1);
      expect(result.messages[0].text).toContain('👋');
    });
  });
  
  describe('member tracking', () => {
    it('assigns same member ID to same author', () => {
      const input = `24/12/2024, 14:35 - Juan: Primer mensaje
24/12/2024, 14:36 - Juan: Segundo mensaje`;
      const result = parseWhatsAppExport(input);
      
      expect(result.messages[0].authorId).toBe(result.messages[1].authorId);
    });
    
    it('assigns different member IDs to different authors', () => {
      const input = `24/12/2024, 14:35 - Juan: Mensaje Juan
24/12/2024, 14:36 - María: Mensaje María`;
      const result = parseWhatsAppExport(input);
      
      expect(result.messages[0].authorId).not.toBe(result.messages[1].authorId);
    });
  });
});
