# RCC-ORG FASE 1

## Objetivo
Importar chat de WhatsApp a SQLite para análisis.

## Uso

### Importar chat
```bash
npm run import -- "Chat de WhatsApp con Equipo.txt" equipo.db
```

### Consultar mensajes
```bash
# Stats
npm run query -- equipo.db --stats

# Listar participantes
npm run query -- equipo.db --members

# Mensajes de un autor
npm run query -- equipo.db --author "Juan"

# Por rango de fechas
npm run query -- equipo.db --from "2024-12-01" --to "2024-12-31"

# Con límite
npm run query -- equipo.db --author "Juan" --limit 10
```

## Formato WhatsApp Soportado

```
DD/MM/YYYY, HH:MM - Nombre: Texto del mensaje
```

Ejemplo:
```
24/12/2024, 14:35 - Juan Pérez: Hola equipo
24/12/2024, 14:36 - María García: Buen día!
```

## Estructura de Datos

### Member
```typescript
{
  id: string;      // ID generado
  name: string;    // Nombre del participante
}
```

### Message
```typescript
{
  id: string;        // ID generado
  authorId: string;  // FK a Member
  text: string;      // Texto del mensaje
  timestamp: number; // Unix ms (UTC)
}
```

## Mensajes Ignorados
- Multimedia (`<Multimedia omitido>`)
- Creación de grupo
- Cambios de ícono/descripción
- Mensajes eliminados
- Mensajes de sistema

## Encoding
UTF-8

## Timezone
UTC-3 (Argentina) hardcoded
