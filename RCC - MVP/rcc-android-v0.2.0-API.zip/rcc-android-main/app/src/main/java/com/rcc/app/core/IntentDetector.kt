package com.rcc.app.core   // tiene que ser la primera línea

enum class IntentType {
    REQUEST_HELP,
    COMPLAINT,
    STATUS_UPDATE,
    INSTRUCTION,
    SMALL_TALK,
    NEUTRAL
}

object IntentDetector {

    fun detect(text: String): IntentType {
        if (text.isBlank()) return IntentType.NEUTRAL

        val t = text.lowercase()

        if (
            listOf("ayuda", "necesito que", "no entiendo", "no sé", "no se", "me podés", "me podes")
                .any { t.contains(it) }
        ) return IntentType.REQUEST_HELP

        if (
            listOf("esto está mal", "esto esta mal", "no funciona", "desastre", "malísimo", "malisimo")
                .any { t.contains(it) }
        ) return IntentType.COMPLAINT

        if (
            listOf("ya hice", "te aviso", "te cuento", "actualizo", "ya lo resolví", "ya lo resolvi")
                .any { t.contains(it) }
        ) return IntentType.STATUS_UPDATE

        if (
            listOf("tenes que", "tenés que", "tienes que", "debes", "hacé", "hace esto", "haga esto")
                .any { t.contains(it) }
        ) return IntentType.INSTRUCTION

        if (
            listOf("buen día", "buen dia", "como andas", "cómo andás", "jaja", "jajaja")
                .any { t.contains(it) }
        ) return IntentType.SMALL_TALK

        return IntentType.NEUTRAL
    }
}
