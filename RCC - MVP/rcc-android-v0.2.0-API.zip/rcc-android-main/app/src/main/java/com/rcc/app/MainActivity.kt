package com.rcc.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.rcc.app.core.RccApiClient
import com.rcc.app.core.TransformResult
import com.rcc.app.ui.theme.RCCTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            RCCTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RCCScreen()
                }
            }
        }
    }
}

enum class ModoRCC(val label: String, val apiValue: String) {
    SUAVE("Suave", "SUAVE"),
    PROFESIONAL("Pro", "PROFESIONAL"),
    EMPATICO("Empático", "EMPATICO")
}

@Composable
fun RCCScreen() {
    var original by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<TransformResult?>(null) }
    var selectedMode by remember { mutableStateOf(ModoRCC.SUAVE) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "RCC — Módem Cognitivo v0.2",
            style = MaterialTheme.typography.titleLarge
        )

        // Selector de modo RCC
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ModoRCC.values().forEach { modo ->
                ModeButton(
                    label = modo.label,
                    selected = selectedMode == modo
                ) { selectedMode = modo }
            }
        }

        // Campo: mensaje original
        OutlinedTextField(
            value = original,
            onValueChange = { original = it },
            label = { Text("Escribí tu mensaje") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )

        // Botón transformar
        Button(
            onClick = {
                if (original.isNotBlank()) {
                    isLoading = true
                    errorMsg = null
                    scope.launch {
                        try {
                            result = RccApiClient.transform(original, selectedMode.apiValue)
                        } catch (e: Exception) {
                            errorMsg = "Error: ${e.message}"
                            result = null
                        } finally {
                            isLoading = false
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading && original.isNotBlank()
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp
                )
                Spacer(Modifier.width(8.dp))
            }
            Text(if (isLoading) "Procesando..." else "Transformar")
        }

        // Error
        errorMsg?.let { msg ->
            Text(
                text = msg,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }

        // Resultado
        result?.let { r ->
            OutlinedTextField(
                value = r.transformed,
                onValueChange = { },
                label = { Text("Mensaje optimizado") },
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                minLines = 3
            )

            // Botón copiar
            Button(
                onClick = {
                    clipboardManager.setText(AnnotatedString(r.transformed))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Copiar mensaje optimizado")
            }

            // Info del análisis
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Análisis",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Estado: ${r.state}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Intensidad: ${(r.score * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Intención: ${formatIntent(r.intent)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

private fun formatIntent(intent: String): String {
    return when (intent) {
        "REQUEST_HELP" -> "Pedido de ayuda"
        "COMPLAINT" -> "Reclamo / queja"
        "STATUS_UPDATE" -> "Actualización de estado"
        "INSTRUCTION" -> "Instrucción / orden"
        "SMALL_TALK" -> "Charla informal"
        else -> "Neutral"
    }
}

@Composable
private fun ModeButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    OutlinedButton(onClick = onClick) {
        Text(text = if (selected) "[$label]" else label)
    }
}

@Preview(showBackground = true)
@Composable
fun RCCPreview() {
    RCCTheme {
        RCCScreen()
    }
}
