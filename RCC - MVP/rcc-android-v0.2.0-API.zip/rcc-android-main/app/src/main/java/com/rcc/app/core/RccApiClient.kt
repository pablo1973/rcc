package com.rcc.app.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class TransformResult(
    val original: String,
    val transformed: String,
    val state: String,
    val score: Double,
    val intent: String
)

object RccApiClient {
    // Cambiar a tu URL de producción después
    private const val BASE_URL = "http://10.0.2.2:3000"  // localhost desde emulador Android
    
    suspend fun transform(text: String, mode: String = "SUAVE"): TransformResult {
        return withContext(Dispatchers.IO) {
            val url = URL("$BASE_URL/transform")
            val connection = url.openConnection() as HttpURLConnection
            
            try {
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                
                val body = JSONObject().apply {
                    put("text", text)
                    put("mode", mode)
                }
                
                connection.outputStream.use { os ->
                    os.write(body.toString().toByteArray())
                }
                
                if (connection.responseCode == 200) {
                    val response = connection.inputStream.bufferedReader().readText()
                    val json = JSONObject(response)
                    
                    TransformResult(
                        original = json.getString("original"),
                        transformed = json.getString("transformed"),
                        state = json.getString("state"),
                        score = json.getDouble("score"),
                        intent = json.getString("intent")
                    )
                } else {
                    throw Exception("API error: ${connection.responseCode}")
                }
            } finally {
                connection.disconnect()
            }
        }
    }
}
