package com.rcc.app.core

class TransformEngine {

    // Modos de salida del RCC
    enum class ModoRCC {
        SUAVE,
        PROFESIONAL,
        EMPATICO
    }

    // Estado interno: modo actual + última intención detectada
    var modo: ModoRCC = ModoRCC.SUAVE
    var lastIntent: IntentType = IntentType.NEUTRAL
        private set

    // Resultado de analizar el tono del mensaje
    data class Tono(
        val esUrgente: Boolean = false,
        val esAnsioso: Boolean = false,
        val esEnojado: Boolean = false
    )

    fun transform(text: String): String {
        if (text.isBlank()) return ""

        val normalizado = normalizar(text)
        val tono = detectarTono(normalizado)
        val intent = IntentDetector.detect(normalizado)
        lastIntent = intent

        val suavizado = aplicarReemplazosBasicos(normalizado)

        return reescribir(suavizado, tono, intent)
    }

    // ---------------- 1) Normalización simple ----------------
    private fun normalizar(t: String): String {
        return t.trim().replace("\\s+".toRegex(), " ")
    }

    // ---------------- 2) Detección de tono ----------------
    private fun detectarTono(t: String): Tono {
        val mayus = t.count { it.isUpperCase() }
        val excls = t.count { it == '!' }

        val urgencia = listOf("urgente", "ya", "ahora", "ya mismo", "tenes que", "tenés que")
            .any { t.contains(it, ignoreCase = true) }

        val ansioso = listOf("no entiendo", "no sé", "no se", "qué hago", "que hago")
            .any { t.contains(it, ignoreCase = true) }

        val enojado = listOf("malísimo", "malisimo", "desastre", "no puedo creer")
            .any { t.contains(it, ignoreCase = true) }

        val esUrgente = urgencia || mayus > 6 || excls >= 2

        return Tono(
            esUrgente = esUrgente,
            esAnsioso = ansioso,
            esEnojado = enojado
        )
    }

    // ------------- 3) Reemplazos básicos de RCC v0.2 -------------
    private fun aplicarReemplazosBasicos(text: String): String {
        var out = text

        out = out.replace("ESTA MAL", "podría mejorar", ignoreCase = true)
        out = out.replace("ESTÁ MAL", "podría mejorar", ignoreCase = true)
        out = out.replace("MAL HECHO", "mejorable", ignoreCase = true)
        out = out.replace("HORRIBLE", "mejorable", ignoreCase = true)
        out = out.replace("UN DESASTRE", "perfectible", ignoreCase = true)
        out = out.replace("URGENTE", "importante", ignoreCase = true)
        out = out.replace("YA MISMO", "cuando puedas revisarlo", ignoreCase = true)
        out = out.replace("TENES QUE", "¿podés?", ignoreCase = true)
        out = out.replace("TENÉS QUE", "¿podés?", ignoreCase = true)

        return out
    }

    // ------------- 4) Reescritura según modo + tono + intención -------------
    private fun reescribir(t: String, tono: Tono, intent: IntentType): String {
        val encabezadoBase = when (modo) {
            ModoRCC.SUAVE -> {
                if (tono.esUrgente || tono.esEnojado)
                    "Te lo marco con calma para que podamos verlo bien.\n\n"
                else
                    "Versión optimizada:\n"
            }
            ModoRCC.PROFESIONAL -> "Resumen claro y profesional:\n"
            ModoRCC.EMPATICO -> "Estoy con vos, vamos paso por paso.\n\n"
        }

        val fraseIntent = when (intent) {
            IntentType.REQUEST_HELP -> "Reformula tu pedido de ayuda así se entiende mejor:\n\n"
            IntentType.COMPLAINT -> "Te ayudo a plantear el reclamo sin romper la relación:\n\n"
            IntentType.STATUS_UPDATE -> "Dejemos clara la actualización de estado:\n\n"
            IntentType.INSTRUCTION -> "Lo dejo como pedido claro y respetuoso:\n\n"
            IntentType.SMALL_TALK -> "Lo adapté como mensaje de charla tranquila:\n\n"
            IntentType.NEUTRAL -> ""
        }

        return encabezadoBase + fraseIntent + t
    }
}