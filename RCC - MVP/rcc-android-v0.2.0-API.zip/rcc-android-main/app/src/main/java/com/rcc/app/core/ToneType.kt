package com.rcc.app.core

enum class ToneType {
    SUAVE,
    PROFESIONAL,
    EMPATICO
}
