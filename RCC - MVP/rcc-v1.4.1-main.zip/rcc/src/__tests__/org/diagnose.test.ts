/**
 * RCC Diagnose Tests
 * Según SPEC exacta
 */

import { generateDiagnoseReport, formatDiagnoseText, formatDiagnoseJson } from '../../org/diagnose';
import { Member, Message } from '../../org/types';
import { DiagnoseReport } from '../../org/diagnose.types';

describe('Diagnose', () => {
  // Helper para crear mensajes
  const createMessage = (
    id: string,
    authorId: string,
    text: string,
    timestamp: number
  ): Message => ({ id, authorId, text, timestamp });
  
  // Datos de prueba: 2 users, 5 msgs
  const members: Member[] = [
    { id: 'u1', name: 'Juan' },
    { id: 'u2', name: 'María' }
  ];
  
  // Juan: 3 msgs (1 tenso), María: 2 msgs (0 tensos)
  // Timestamps: 20/12/2024 y 21/12/2024
  const day1 = Date.UTC(2024, 11, 20, 10, 0, 0); // 20/12/2024 10:00
  const day2 = Date.UTC(2024, 11, 21, 14, 0, 0); // 21/12/2024 14:00
  
  const messages: Message[] = [
    createMessage('m1', 'u1', 'Hola equipo buen día', day1),
    createMessage('m2', 'u1', 'ESTO ES URGENTE!!! NECESITO RESPUESTA YA!!!', day1 + 3600000),
    createMessage('m3', 'u2', 'Todo tranquilo por acá', day1 + 7200000),
    createMessage('m4', 'u1', 'Gracias por responder tan rápido', day2),
    createMessage('m5', 'u2', 'De nada, siempre a disposición', day2 + 3600000)
  ];
  
  describe('generateDiagnoseReport', () => {
    it('genera reporte con estructura correcta', () => {
      const report = generateDiagnoseReport(members, messages, {});
      
      expect(report.meta).toBeDefined();
      expect(report.meta.users).toBe(2);
      expect(report.meta.messages).toBe(5);
      expect(report.topFriction).toBeDefined();
      expect(report.userMetrics).toBeDefined();
      expect(report.examples).toBeDefined();
    });
    
    it('topFriction ordenado por frictionScore desc (determinístico)', () => {
      const report = generateDiagnoseReport(members, messages, { top: 2 });
      
      // Juan tiene mensaje tenso, debe tener mayor frictionScore
      expect(report.topFriction.length).toBeLessThanOrEqual(2);
      expect(report.topFriction[0].name).toBe('Juan');
      
      // Verificar orden descendente
      for (let i = 1; i < report.topFriction.length; i++) {
        expect(report.topFriction[i - 1].frictionScore)
          .toBeGreaterThanOrEqual(report.topFriction[i].frictionScore);
      }
    });
    
    it('--from/--to filtra por dateKey inclusive', () => {
      // Solo día 20
      const report = generateDiagnoseReport(members, messages, {
        from: '2024-12-20',
        to: '2024-12-20'
      });
      
      expect(report.meta.messages).toBe(3); // 3 mensajes del día 20
    });
    
    it('--user filtra solo a ese usuario', () => {
      const report = generateDiagnoseReport(members, messages, {
        user: 'Juan'
      });
      
      expect(report.meta.users).toBe(1);
      expect(report.userMetrics.length).toBe(1);
      expect(report.userMetrics[0].name).toBe('Juan');
      expect(report.userMetrics[0].messageCount).toBe(3);
    });
    
    it('--min-words ignora mensajes cortos', () => {
      const shortMessages: Message[] = [
        createMessage('s1', 'u1', 'ok', day1),  // 1 palabra - ignorar
        createMessage('s2', 'u1', 'sí dale', day1), // 2 palabras - ignorar
        createMessage('s3', 'u1', 'Hola qué tal', day1) // 3 palabras - incluir
      ];
      
      const report = generateDiagnoseReport(members, shortMessages, {
        minWords: 3
      });
      
      expect(report.meta.messages).toBe(1);
    });
    
    it('frictionScore está entre 0 y 100', () => {
      const report = generateDiagnoseReport(members, messages, {});
      
      for (const user of report.userMetrics) {
        expect(user.frictionScore).toBeGreaterThanOrEqual(0);
        expect(user.frictionScore).toBeLessThanOrEqual(100);
      }
    });
    
    it('examples contiene mensajes tensos ordenados por intensity', () => {
      const report = generateDiagnoseReport(members, messages, {
        examples: 3
      });
      
      // Solo hay 1 mensaje tenso en los datos de prueba
      expect(report.examples.length).toBeGreaterThan(0);
      
      // Verificar orden descendente por intensity
      for (let i = 1; i < report.examples.length; i++) {
        expect(report.examples[i - 1].intensity)
          .toBeGreaterThanOrEqual(report.examples[i].intensity);
      }
    });
    
    it('examples incluye regulatedText cuando includeRegulated=true', () => {
      const report = generateDiagnoseReport(members, messages, {
        examples: 3,
        includeRegulated: true
      });
      
      if (report.examples.length > 0) {
        expect(report.examples[0].regulatedText).toBeDefined();
      }
    });
    
    it('examples NO incluye regulatedText cuando includeRegulated=false', () => {
      const report = generateDiagnoseReport(members, messages, {
        examples: 3,
        includeRegulated: false
      });
      
      for (const ex of report.examples) {
        expect(ex.regulatedText).toBeUndefined();
      }
    });
  });
  
  describe('formatDiagnoseJson', () => {
    it('produce JSON parseable con keys correctas', () => {
      const report = generateDiagnoseReport(members, messages, {});
      const json = formatDiagnoseJson(report);
      
      // Debe ser parseable
      const parsed = JSON.parse(json) as DiagnoseReport;
      
      // Keys requeridas
      expect(parsed.meta).toBeDefined();
      expect(parsed.meta.users).toBeDefined();
      expect(parsed.meta.messages).toBeDefined();
      expect(parsed.topFriction).toBeDefined();
      expect(parsed.userMetrics).toBeDefined();
      expect(parsed.examples).toBeDefined();
      
      // Estructura de userMetrics
      if (parsed.userMetrics.length > 0) {
        const user = parsed.userMetrics[0];
        expect(user.userId).toBeDefined();
        expect(user.name).toBeDefined();
        expect(user.messageCount).toBeDefined();
        expect(user.tenseCount).toBeDefined();
        expect(user.avgIntensity).toBeDefined();
        expect(user.frictionScore).toBeDefined();
        expect(user.triggers).toBeDefined();
      }
      
      // Estructura de examples
      if (parsed.examples.length > 0) {
        const ex = parsed.examples[0];
        expect(ex.userId).toBeDefined();
        expect(ex.name).toBeDefined();
        expect(ex.dateKey).toBeDefined();
        expect(ex.originalText).toBeDefined();
        expect(ex.intensity).toBeDefined();
      }
    });
  });
  
  describe('formatDiagnoseText', () => {
    it('incluye secciones requeridas', () => {
      const report = generateDiagnoseReport(members, messages, {});
      const text = formatDiagnoseText(report);
      
      expect(text).toContain('RCC DIAGNOSE');
      expect(text).toContain('TOP FRICTION');
      expect(text).toContain('USER METRICS');
      expect(text).toContain('EXAMPLES');
    });
  });
});
