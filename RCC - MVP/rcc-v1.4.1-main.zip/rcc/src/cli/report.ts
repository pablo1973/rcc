/**
 * RCC-ORG CLI Report
 * FASE 2 - Generar reporte de métricas
 * 
 * Uso:
 *   npx ts-node src/cli/report.ts <db>
 *   npx ts-node src/cli/report.ts <db> --markdown
 *   npx ts-node src/cli/report.ts <db> --output report.md
 */

import * as fs from 'fs';
import { initDatabase, queryMessages, queryMembers, closeDatabase } from '../org/storage';
import { generateMetricsReport, formatReportConsole, formatReportMarkdown } from '../org/metrics';

async function main() {
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    console.error('Uso: npx ts-node src/cli/report.ts <db> [opciones]');
    console.error('');
    console.error('Opciones:');
    console.error('  --markdown           Formato Markdown en lugar de consola');
    console.error('  --output <archivo>   Guardar reporte en archivo');
    console.error('  --json               Output JSON crudo');
    process.exit(1);
  }
  
  const dbPath = args[0];
  
  if (!fs.existsSync(dbPath)) {
    console.error(`Error: Base de datos no encontrada: ${dbPath}`);
    process.exit(1);
  }
  
  // Parse args
  let useMarkdown = false;
  let outputFile: string | undefined;
  let useJson = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--markdown':
      case '-m':
        useMarkdown = true;
        break;
      case '--output':
      case '-o':
        outputFile = args[++i];
        break;
      case '--json':
        useJson = true;
        break;
    }
  }
  
  // Cargar datos
  await initDatabase(dbPath);
  const members = queryMembers();
  const messages = queryMessages();
  closeDatabase();
  
  // Generar reporte
  const report = generateMetricsReport(members, messages);
  
  // Formatear output
  let output: string;
  if (useJson) {
    output = JSON.stringify(report, null, 2);
  } else if (useMarkdown) {
    output = formatReportMarkdown(report);
  } else {
    output = formatReportConsole(report);
  }
  
  // Escribir output
  if (outputFile) {
    fs.writeFileSync(outputFile, output, 'utf-8');
    console.log(`✅ Reporte guardado en: ${outputFile}`);
  } else {
    console.log(output);
  }
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
