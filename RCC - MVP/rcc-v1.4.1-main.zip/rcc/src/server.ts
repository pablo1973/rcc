/**
 * RCC API Server
 * Solo endpoint: POST /diagnose
 */

import http from 'http';
import { generateDiagnoseReport, formatDiagnoseJson } from './org/diagnose';
import { Message, Member } from './org/types';

const PORT = process.env.PORT || 3000;

interface DiagnoseRequest {
  members: Member[];
  messages: Message[];
  from?: string;
  to?: string;
  user?: string;
  top?: number;
  examples?: number;
  minWords?: number;
  includeRegulated?: boolean;
}

function handleRequest(req: http.IncomingMessage, res: http.ServerResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Content-Type', 'application/json');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = req.url || '/';

  // Health check
  if (url === '/health' && req.method === 'GET') {
    res.writeHead(200);
    res.end(JSON.stringify({ status: 'ok', version: '1.4.1' }));
    return;
  }

  // POST /diagnose
  if (url === '/diagnose' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const data = JSON.parse(body) as DiagnoseRequest;

        if (!data.members || !data.messages) {
          res.writeHead(400);
          res.end(JSON.stringify({ error: 'Missing members or messages' }));
          return;
        }

        const report = generateDiagnoseReport(data.members, data.messages, {
          from: data.from,
          to: data.to,
          user: data.user,
          top: data.top,
          examples: data.examples,
          minWords: data.minWords,
          includeRegulated: data.includeRegulated
        });

        res.writeHead(200);
        res.end(formatDiagnoseJson(report));
      } catch (e) {
        res.writeHead(400);
        res.end(JSON.stringify({ error: 'Invalid JSON' }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end(JSON.stringify({ error: 'Not found. Use POST /diagnose' }));
}

const server = http.createServer(handleRequest);

server.listen(PORT, () => {
  console.log(`RCC API running on http://localhost:${PORT}`);
  console.log('Endpoints:');
  console.log('  GET  /health    - Health check');
  console.log('  POST /diagnose  - Generate DiagnoseReport');
});
