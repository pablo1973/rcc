/**
 * RCC-ORG Types
 * FASE 1 - Mínimo viable
 */

export interface Member {
  id: string;
  name: string;
}

export interface Message {
  id: string;
  authorId: string;
  text: string;
  timestamp: number;  // Unix ms
}

export interface ParseResult {
  members: Member[];
  messages: Message[];
  errors: string[];   // Líneas que no se pudieron parsear
}
