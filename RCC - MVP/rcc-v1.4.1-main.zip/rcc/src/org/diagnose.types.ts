/**
 * RCC Diagnose Types
 * FASE 2 MVP - Según SPEC exacta
 */

export interface DiagnoseMeta {
  from?: string;
  to?: string;
  users: number;
  messages: number;
}

export interface UserFriction {
  userId: string;
  name: string;
  messageCount: number;
  wordCount: number;
  avgMessageLengthChars: number;
  avgWordsPerMessage: number;
  tenseCount: number;
  avgIntensity: number;
  frictionScore: number;
  triggers: string[];
}

export interface DiagnoseExample {
  userId: string;
  name: string;
  dateKey: string;
  originalText: string;
  regulatedText?: string;
  intensity: number;
}

export interface DiagnoseReport {
  meta: DiagnoseMeta;
  topFriction: UserFriction[];
  userMetrics: UserFriction[];
  examples: DiagnoseExample[];
}

export interface DiagnoseOptions {
  from?: string;          // YYYY-MM-DD
  to?: string;            // YYYY-MM-DD
  user?: string;          // filtrar a 1 usuario
  top?: number;           // default 3
  examples?: number;      // default 3
  minWords?: number;      // default 3
  includeRegulated?: boolean; // default true
}
