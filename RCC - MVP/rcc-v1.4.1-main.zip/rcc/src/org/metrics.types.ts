/**
 * RCC-ORG Metrics Types
 * FASE 2 - Métricas por usuario
 */

export interface UserMetrics {
  userId: string;
  userName: string;
  
  // Volumen
  messageCount: number;
  wordCount: number;
  avgWordsPerMessage: number;
  
  // Timing
  firstMessageAt: number;      // timestamp
  lastMessageAt: number;       // timestamp
  activeDays: number;          // días únicos con actividad
  peakHour: number;            // hora con más mensajes (0-23)
  hourDistribution: number[];  // mensajes por hora [0-23]
  
  // Intensidad (del core)
  avgIntensity: number;        // 0-1
  tenseMessageCount: number;   // mensajes con state TENSE
  calmMessageCount: number;    // mensajes con state CALM
}

export interface ChannelMetrics {
  totalMessages: number;
  totalMembers: number;
  dateRange: {
    from: number;
    to: number;
  };
  avgMessagesPerDay: number;
  mostActiveUser: string;
  leastActiveUser: string;
}

export interface MetricsReport {
  channel: ChannelMetrics;
  users: UserMetrics[];
  generatedAt: number;
}
