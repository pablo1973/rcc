/**
 * RCC Diagnose
 * FASE 2 MVP - Según SPEC exacta
 */

import { Message, Member } from './types';
import { 
  DiagnoseReport, 
  DiagnoseOptions, 
  UserFriction, 
  DiagnoseExample 
} from './diagnose.types';
import { analyze } from '../core/analyzer';
import { regulate } from '../core/regulator';

/**
 * Genera dateKey desde timestamp (YYYY-MM-DD)
 */
function getDateKey(timestamp: number): string {
  const d = new Date(timestamp);
  const year = d.getUTCFullYear();
  const month = String(d.getUTCMonth() + 1).padStart(2, '0');
  const day = String(d.getUTCDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Genera hora desde timestamp (HH:MM)
 */
function getTimeKey(timestamp: number): string {
  const d = new Date(timestamp);
  const hour = String(d.getUTCHours()).padStart(2, '0');
  const min = String(d.getUTCMinutes()).padStart(2, '0');
  return `${hour}:${min}`;
}

/**
 * Cuenta palabras en texto
 */
function countWords(text: string): number {
  return text.split(/\s+/).filter(w => w.length > 0).length;
}

/**
 * Filtra mensajes por opciones
 */
function filterMessages(
  messages: Message[],
  members: Member[],
  options: DiagnoseOptions
): Message[] {
  let filtered = [...messages];
  
  // Filtrar por fecha
  if (options.from) {
    const fromDate = options.from;
    filtered = filtered.filter(m => getDateKey(m.timestamp) >= fromDate);
  }
  
  if (options.to) {
    const toDate = options.to;
    filtered = filtered.filter(m => getDateKey(m.timestamp) <= toDate);
  }
  
  // Filtrar por usuario
  if (options.user) {
    const memberMap = new Map(members.map(m => [m.id, m.name]));
    const targetName = options.user.toLowerCase();
    filtered = filtered.filter(m => {
      const name = memberMap.get(m.authorId)?.toLowerCase() || '';
      return name.includes(targetName);
    });
  }
  
  // Filtrar por min-words
  const minWords = options.minWords ?? 3;
  filtered = filtered.filter(m => countWords(m.text) >= minWords);
  
  return filtered;
}

/**
 * Calcula métricas de fricción por usuario
 */
function computeUserFriction(
  userId: string,
  userName: string,
  messages: Message[]
): UserFriction {
  if (messages.length === 0) {
    return {
      userId,
      name: userName,
      messageCount: 0,
      wordCount: 0,
      avgMessageLengthChars: 0,
      avgWordsPerMessage: 0,
      tenseCount: 0,
      avgIntensity: 0,
      frictionScore: 0,
      triggers: []
    };
  }
  
  let totalChars = 0;
  let totalWords = 0;
  let tenseCount = 0;
  let totalIntensity = 0;
  const triggerCounts: Map<string, number> = new Map();
  
  for (const msg of messages) {
    totalChars += msg.text.length;
    totalWords += countWords(msg.text);
    
    const analysis = analyze(msg.text);
    totalIntensity += analysis.score;
    
    if (analysis.state === 'TENSE') {
      tenseCount++;
    }
    
    // Agregar reason como trigger
    if (analysis.reason && analysis.reason !== 'BASELINE') {
      const count = triggerCounts.get(analysis.reason) || 0;
      triggerCounts.set(analysis.reason, count + 1);
    }
  }
  
  const messageCount = messages.length;
  const avgIntensity = totalIntensity / messageCount;
  const tenseRate = tenseCount / messageCount;
  
  // frictionScore = round(100 * (0.7*tenseRate + 0.3*avgIntensity))
  const frictionScore = Math.min(100, Math.max(0, 
    Math.round(100 * (0.7 * tenseRate + 0.3 * avgIntensity))
  ));
  
  // Top 5 triggers por frecuencia
  const triggers = Array.from(triggerCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([trigger]) => trigger);
  
  return {
    userId,
    name: userName,
    messageCount,
    wordCount: totalWords,
    avgMessageLengthChars: Math.round(totalChars / messageCount * 100) / 100,
    avgWordsPerMessage: Math.round(totalWords / messageCount * 100) / 100,
    tenseCount,
    avgIntensity: Math.round(avgIntensity * 1000) / 1000,
    frictionScore,
    triggers
  };
}

/**
 * Selecciona ejemplos de mensajes tensos con before/after
 */
function selectExamples(
  messages: Message[],
  members: Member[],
  options: DiagnoseOptions
): DiagnoseExample[] {
  const memberMap = new Map(members.map(m => [m.id, m.name]));
  const includeRegulated = options.includeRegulated ?? true;
  const maxExamples = options.examples ?? 3;
  
  // Analizar todos los mensajes y filtrar TENSE
  const tenseMessages: Array<{
    msg: Message;
    analysis: ReturnType<typeof analyze>;
  }> = [];
  
  for (const msg of messages) {
    const analysis = analyze(msg.text);
    if (analysis.state === 'TENSE') {
      tenseMessages.push({ msg, analysis });
    }
  }
  
  // Ordenar por intensity desc
  tenseMessages.sort((a, b) => b.analysis.score - a.analysis.score);
  
  // Tomar top N
  const selected = tenseMessages.slice(0, maxExamples);
  
  return selected.map(({ msg, analysis }) => {
    const example: DiagnoseExample = {
      userId: msg.authorId,
      name: memberMap.get(msg.authorId) || 'Unknown',
      dateKey: `${getDateKey(msg.timestamp)} ${getTimeKey(msg.timestamp)}`,
      originalText: msg.text,
      intensity: analysis.score
    };
    
    if (includeRegulated) {
      const regulation = regulate(analysis, msg.text);
      example.regulatedText = regulation.message;
    }
    
    return example;
  });
}

/**
 * Genera reporte de diagnóstico
 */
export function generateDiagnoseReport(
  members: Member[],
  messages: Message[],
  options: DiagnoseOptions = {}
): DiagnoseReport {
  // Filtrar mensajes
  const filtered = filterMessages(messages, members, options);
  
  // Obtener usuarios únicos en mensajes filtrados
  const userIds = new Set(filtered.map(m => m.authorId));
  const memberMap = new Map(members.map(m => [m.id, m]));
  
  // Calcular métricas por usuario
  const userMetrics: UserFriction[] = [];
  
  for (const userId of userIds) {
    const member = memberMap.get(userId);
    if (!member) continue;
    
    const userMessages = filtered.filter(m => m.authorId === userId);
    const friction = computeUserFriction(userId, member.name, userMessages);
    userMetrics.push(friction);
  }
  
  // Ordenar por frictionScore desc
  userMetrics.sort((a, b) => b.frictionScore - a.frictionScore);
  
  // Top N por fricción
  const topN = options.top ?? 3;
  const topFriction = userMetrics.slice(0, topN);
  
  // Seleccionar ejemplos
  const examples = selectExamples(filtered, members, options);
  
  // Construir meta
  const meta = {
    from: options.from,
    to: options.to,
    users: userIds.size,
    messages: filtered.length
  };
  
  return {
    meta,
    topFriction,
    userMetrics,
    examples
  };
}

/**
 * Formatea reporte como texto plano
 */
export function formatDiagnoseText(report: DiagnoseReport): string {
  const lines: string[] = [];
  
  // Header
  const rangeStr = report.meta.from || report.meta.to
    ? `${report.meta.from || '*'} to ${report.meta.to || '*'}`
    : 'all';
  
  lines.push('RCC DIAGNOSE (MVP)');
  lines.push(`Range: ${rangeStr}   Users: ${report.meta.users}   Messages: ${report.meta.messages}`);
  lines.push('');
  
  // Top Friction
  lines.push('TOP FRICTION (by frictionScore)');
  report.topFriction.forEach((u, i) => {
    lines.push(
      `${i + 1}) ${u.name} score=${u.frictionScore} msgs=${u.messageCount} ` +
      `tense=${u.tenseCount} avgIntensity=${u.avgIntensity.toFixed(2)}`
    );
  });
  lines.push('');
  
  // User Metrics
  lines.push('USER METRICS');
  for (const u of report.userMetrics) {
    const triggersStr = u.triggers.length > 0 ? u.triggers.join(', ') : '-';
    lines.push(
      `- ${u.name}: msgs=${u.messageCount} words=${u.wordCount} ` +
      `avgWords=${u.avgWordsPerMessage.toFixed(2)} tenseRate=${(u.tenseCount / Math.max(1, u.messageCount)).toFixed(2)} ` +
      `avgIntensity=${u.avgIntensity.toFixed(2)} score=${u.frictionScore}`
    );
    lines.push(`  triggers: ${triggersStr}`);
  }
  lines.push('');
  
  // Examples
  lines.push('EXAMPLES (before/after)');
  report.examples.forEach((ex, i) => {
    lines.push(`[${i + 1}] ${ex.name} ${ex.dateKey}`);
    lines.push(`ORIG: ${truncate(ex.originalText, 280)}`);
    if (ex.regulatedText) {
      lines.push(`REG : ${truncate(ex.regulatedText, 280)}`);
    }
    lines.push('');
  });
  
  return lines.join('\n');
}

/**
 * Formatea reporte como Markdown
 */
export function formatDiagnoseMd(report: DiagnoseReport): string {
  const lines: string[] = [];
  
  const rangeStr = report.meta.from || report.meta.to
    ? `${report.meta.from || '*'} to ${report.meta.to || '*'}`
    : 'all';
  
  lines.push('# RCC Diagnose');
  lines.push('');
  lines.push(`**Range:** ${rangeStr} | **Users:** ${report.meta.users} | **Messages:** ${report.meta.messages}`);
  lines.push('');
  
  // Top Friction
  lines.push('## Top Friction');
  lines.push('');
  lines.push('| # | Name | Score | Msgs | Tense | Avg Intensity |');
  lines.push('|---|------|-------|------|-------|---------------|');
  report.topFriction.forEach((u, i) => {
    lines.push(
      `| ${i + 1} | ${u.name} | ${u.frictionScore} | ${u.messageCount} | ` +
      `${u.tenseCount} | ${u.avgIntensity.toFixed(2)} |`
    );
  });
  lines.push('');
  
  // User Metrics
  lines.push('## User Metrics');
  lines.push('');
  for (const u of report.userMetrics) {
    const triggersStr = u.triggers.length > 0 ? u.triggers.join(', ') : '-';
    const tenseRate = (u.tenseCount / Math.max(1, u.messageCount)).toFixed(2);
    lines.push(`### ${u.name}`);
    lines.push(`- Messages: ${u.messageCount}, Words: ${u.wordCount}, Avg words/msg: ${u.avgWordsPerMessage.toFixed(2)}`);
    lines.push(`- Tense rate: ${tenseRate}, Avg intensity: ${u.avgIntensity.toFixed(2)}, **Score: ${u.frictionScore}**`);
    lines.push(`- Triggers: ${triggersStr}`);
    lines.push('');
  }
  
  // Examples
  lines.push('## Examples (Before/After)');
  lines.push('');
  report.examples.forEach((ex, i) => {
    lines.push(`### [${i + 1}] ${ex.name} — ${ex.dateKey}`);
    lines.push('');
    lines.push(`**Original:** ${ex.originalText}`);
    if (ex.regulatedText) {
      lines.push('');
      lines.push(`**Regulated:** ${ex.regulatedText}`);
    }
    lines.push('');
  });
  
  return lines.join('\n');
}

/**
 * Formatea reporte como JSON
 */
export function formatDiagnoseJson(report: DiagnoseReport): string {
  return JSON.stringify(report, null, 2);
}

/**
 * Trunca texto a N caracteres
 */
function truncate(text: string, maxLen: number): string {
  if (text.length <= maxLen) return text;
  return text.substring(0, maxLen - 3) + '...';
}
