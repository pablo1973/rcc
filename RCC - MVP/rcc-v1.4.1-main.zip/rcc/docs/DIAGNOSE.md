# RCC Diagnose - FASE 2 MVP

## Objetivo
Dado un chat de WhatsApp, generar diagnóstico vendible con:
- Top usuarios por fricción
- Métricas por usuario
- Ejemplos before/after

## Uso

### Desde base de datos existente
```bash
npm run diagnose -- --db equipo.db
```

### Desde chat.txt (importa y diagnostica)
```bash
npm run diagnose -- --chat "Chat.txt" --outdb equipo.db
```

### Opciones completas
```bash
npm run diagnose -- --db equipo.db \
  --from 2024-12-01 \
  --to 2024-12-31 \
  --user "Juan" \
  --top 5 \
  --examples 5 \
  --format md \
  --out reporte.md \
  --min-words 3 \
  --include-regulated true
```

## Opciones

| Opción | Descripción | Default |
|--------|-------------|---------|
| `--db` | Base de datos SQLite | (requerido si no hay --chat) |
| `--chat` | Archivo chat.txt | (requerido si no hay --db) |
| `--outdb` | DB de salida | (requerido con --chat) |
| `--from` | Filtrar desde fecha (YYYY-MM-DD) | - |
| `--to` | Filtrar hasta fecha (inclusivo) | - |
| `--user` | Filtrar a un usuario | - |
| `--top` | Top N usuarios por fricción | 3 |
| `--examples` | Cantidad de ejemplos | 3 |
| `--format` | Formato: text, md, json | text |
| `--out` | Archivo de salida | stdout |
| `--min-words` | Ignorar mensajes cortos | 3 |
| `--include-regulated` | Incluir reescritura | true |

## Exit Codes
- `0` - OK
- `2` - Bad args
- `3` - No data found

## Métricas por Usuario

| Métrica | Descripción |
|---------|-------------|
| `messageCount` | Total de mensajes |
| `wordCount` | Total de palabras |
| `avgWordsPerMessage` | Promedio palabras/mensaje |
| `tenseCount` | Mensajes tensos |
| `avgIntensity` | Intensidad promedio (0-1) |
| `frictionScore` | Score 0-100 |
| `triggers` | Top 5 triggers |

### FrictionScore
```
tenseRate = tenseCount / messageCount
frictionScore = round(100 * (0.7*tenseRate + 0.3*avgIntensity))
```

## Ejemplo de Output (text)

```
RCC DIAGNOSE (MVP)
Range: 2024-12-20 to 2024-12-21   Users: 3   Messages: 19

TOP FRICTION (by frictionScore)
1) Juan Pérez score=43 msgs=7 tense=3 avgIntensity=0.43
2) Carlos López score=17 msgs=6 tense=1 avgIntensity=0.16
3) María García score=2 msgs=6 tense=0 avgIntensity=0.07

USER METRICS
- Juan Pérez: msgs=7 words=36 avgWords=5.14 tenseRate=0.43 avgIntensity=0.43 score=43
  triggers: LOW_INTENSITY, HIGH_INTENSITY

EXAMPLES (before/after)
[1] Juan Pérez 2024-12-20 10:31
ORIG: POR QUÉ NADIE CONTESTA??? ESTO ES IMPORTANTE!!!
REG : Por qué nadie contesta? Esto es importante!
```

## Transformación TENSE (Before/After)

Los mensajes detectados como TENSE son suavizados:
- Mayúsculas excesivas (>50%) → sentence case
- Múltiples exclamaciones (`!!!`) → una sola (`!`)
- Múltiples interrogaciones (`???`) → una sola (`?`)

Esto permite mostrar ejemplos concretos de cómo RCC mejoraría la comunicación.
