# RCC-ORG FASE 2

## Objetivo
Generar métricas por usuario a partir de chats importados.

## Uso

### Generar reporte
```bash
# Consola (default)
npm run report -- equipo.db

# Markdown
npm run report -- equipo.db --markdown

# Guardar en archivo
npm run report -- equipo.db --markdown --output reporte.md

# JSON crudo
npm run report -- equipo.db --json
```

## Métricas por Usuario

| Métrica | Descripción |
|---------|-------------|
| messageCount | Total de mensajes enviados |
| wordCount | Total de palabras |
| avgWordsPerMessage | Promedio de palabras por mensaje |
| activeDays | Días únicos con actividad |
| peakHour | Hora del día con más actividad (0-23) |
| hourDistribution | Distribución de mensajes por hora |
| avgIntensity | Intensidad promedio (0-1) usando analyzer core |
| tenseMessageCount | Cantidad de mensajes tensos |
| calmMessageCount | Cantidad de mensajes calmos |

## Métricas del Canal

| Métrica | Descripción |
|---------|-------------|
| totalMessages | Total de mensajes |
| totalMembers | Total de participantes |
| dateRange | Período analizado |
| avgMessagesPerDay | Promedio de mensajes por día |
| mostActiveUser | Usuario más activo |
| leastActiveUser | Usuario menos activo |

## Ejemplo de Output

```
═══════════════════════════════════════════════════════════════
                    📊 RCC METRICS REPORT
═══════════════════════════════════════════════════════════════

📈 RESUMEN DEL CANAL
───────────────────────────────────────────────────────────────
   Mensajes totales:    38
   Participantes:       3
   Período:             20/12/2024 - 22/12/2024
   Promedio/día:        12.7 mensajes

👥 MÉTRICAS POR USUARIO
───────────────────────────────────────────────────────────────

   📌 Juan Pérez
      Mensajes:         16
      Palabras:         57 (3.6 prom/msg)
      Días activos:     3
      Hora pico:        12:00
      Intensidad:       [█░░░░░░░░░] 14.7%
      Tensión:          1 msgs tensos, 15 calmos
```

## Integración con Core

Las métricas de intensidad usan el `analyzer` del core RCC para clasificar cada mensaje en CALM/NEUTRAL/TENSE basándose en:
- Uso de mayúsculas
- Signos de exclamación/interrogación
- Ruido en el texto
