/**
 * Demo CLI Tests
 */

import { formatMetrics, formatResult, processCommand } from '../demo/cli';

describe('Demo CLI', () => {
  describe('formatMetrics', () => {
    it('returns formatted string for empty input', () => {
      const result = formatMetrics('');
      expect(result).toContain('MÉTRICAS');
      expect(result).toContain('chars:');
      expect(result).toContain('words:');
      expect(result).toContain('intensity:');
      expect(result).toContain('repetition:');
      expect(result).toContain('noise:');
    });

    it('returns formatted string for text input', () => {
      const result = formatMetrics('Hello world');
      expect(result).toContain('MÉTRICAS');
      expect(typeof result).toBe('string');
    });

    it('shows numeric values', () => {
      const result = formatMetrics('Test message');
      expect(result).toMatch(/chars:\s+\d+/);
      expect(result).toMatch(/words:\s+\d+/);
    });
  });

  describe('formatResult', () => {
    it('returns complete pipeline output', () => {
      const result = formatResult('Hello');
      expect(result).toContain('MÉTRICAS');
      expect(result).toContain('ESTADO');
      expect(result).toContain('INPUT');
      expect(result).toContain('OUTPUT REGULADO');
    });

    it('includes the input text', () => {
      const input = 'Test input message';
      const result = formatResult(input);
      expect(result).toContain(input);
    });

    it('includes state information', () => {
      const result = formatResult('Any text');
      // Should contain one of the valid states
      expect(
        result.includes('CALM') || 
        result.includes('NEUTRAL') || 
        result.includes('TENSE')
      ).toBe(true);
    });

    it('handles multiline input', () => {
      const input = 'Line 1\nLine 2\nLine 3';
      const result = formatResult(input);
      expect(result).toContain('Line 1');
      expect(result).toContain('Line 2');
      expect(result).toContain('Line 3');
    });
  });

  describe('processCommand', () => {
    it('returns false for /quit', () => {
      expect(processCommand('/quit')).toBe(false);
    });

    it('returns false for /exit', () => {
      expect(processCommand('/exit')).toBe(false);
    });

    it('returns false for /q', () => {
      expect(processCommand('/q')).toBe(false);
    });

    it('returns true for /help', () => {
      expect(processCommand('/help')).toBe(true);
    });

    it('returns true for /h', () => {
      expect(processCommand('/h')).toBe(true);
    });

    it('returns true for /clear', () => {
      expect(processCommand('/clear')).toBe(true);
    });

    it('returns true for /c', () => {
      expect(processCommand('/c')).toBe(true);
    });

    it('returns true for unknown commands', () => {
      expect(processCommand('/unknown')).toBe(true);
    });

    it('is case insensitive', () => {
      expect(processCommand('/QUIT')).toBe(false);
      expect(processCommand('/HELP')).toBe(true);
    });

    it('trims whitespace', () => {
      expect(processCommand('  /quit  ')).toBe(false);
      expect(processCommand('  /help  ')).toBe(true);
    });
  });

  describe('Output formatting', () => {
    it('uses box drawing characters', () => {
      const result = formatResult('Test');
      expect(result).toContain('┌');
      expect(result).toContain('│');
      expect(result).toContain('└');
      expect(result).toContain('─');
    });

    it('is deterministic', () => {
      const input = 'Determinism test';
      const result1 = formatResult(input);
      const result2 = formatResult(input);
      expect(result1).toBe(result2);
    });
  });
});
