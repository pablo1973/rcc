export type Channel = "cli" | "slack";
export interface InputMessage {
  id: string;
  text: string;
  author: string;
  channel: Channel;
  timestamp: number;
}
