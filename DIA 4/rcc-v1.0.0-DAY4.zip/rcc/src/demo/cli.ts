#!/usr/bin/env node
/**
 * RCC Demo CLI
 * Pipeline: Input → Analyze → Regulate → Output
 */

import * as readline from 'readline';
import { analyze } from '../core/analyzer';
import { computeMetrics } from '../core/heuristics';

const BANNER = `
╔═══════════════════════════════════════════════════════════╗
║           RCC - Regulador Cognitivo Conversacional        ║
║                      Demo CLI v1.0.0                      ║
╠═══════════════════════════════════════════════════════════╣
║  Escribe un mensaje para ver el pipeline de regulación.   ║
║  Comandos: /quit (salir) | /help (ayuda)                  ║
╚═══════════════════════════════════════════════════════════╝
`;

const HELP = `
Comandos disponibles:
  /quit, /exit, /q  - Salir de la demo
  /help, /h         - Mostrar esta ayuda
  /clear, /c        - Limpiar pantalla

Cualquier otro texto será procesado por el pipeline RCC.
`;

function formatMetrics(text: string): string {
  const m = computeMetrics(text);
  return `
┌─ MÉTRICAS ─────────────────────────────────────────────────
│ chars:      ${m.chars.toString().padStart(4)}
│ words:      ${m.words.toString().padStart(4)}
│ intensity:  ${m.intensity.toFixed(2).padStart(4)}  [0..1]
│ repetition: ${m.repetition.toFixed(2).padStart(4)}  [0..1]
│ noise:      ${m.noise.toFixed(2).padStart(4)}  [0..1]
└────────────────────────────────────────────────────────────`;
}

function formatResult(input: string): string {
  const result = analyze(input);
  const metrics = formatMetrics(input);
  
  return `
${metrics}

┌─ ESTADO ───────────────────────────────────────────────────
│ ${result.state}
└────────────────────────────────────────────────────────────

┌─ INPUT ────────────────────────────────────────────────────
│ ${input.split('\n').join('\n│ ')}
└────────────────────────────────────────────────────────────

┌─ OUTPUT REGULADO ──────────────────────────────────────────
│ ${result.regulatedText.split('\n').join('\n│ ')}
└────────────────────────────────────────────────────────────
`;
}

function processCommand(cmd: string): boolean {
  const normalized = cmd.toLowerCase().trim();
  
  switch (normalized) {
    case '/quit':
    case '/exit':
    case '/q':
      console.log('\n👋 Hasta luego.\n');
      return false;
      
    case '/help':
    case '/h':
      console.log(HELP);
      return true;
      
    case '/clear':
    case '/c':
      console.clear();
      console.log(BANNER);
      return true;
      
    default:
      return true;
  }
}

function main(): void {
  console.log(BANNER);
  
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: '\n📝 Input > '
  });
  
  rl.prompt();
  
  rl.on('line', (line: string) => {
    const input = line.trim();
    
    if (!input) {
      rl.prompt();
      return;
    }
    
    if (input.startsWith('/')) {
      if (!processCommand(input)) {
        rl.close();
        return;
      }
    } else {
      console.log(formatResult(input));
    }
    
    rl.prompt();
  });
  
  rl.on('close', () => {
    process.exit(0);
  });
}

// Run if executed directly
if (require.main === module) {
  main();
}

export { formatMetrics, formatResult, processCommand };
