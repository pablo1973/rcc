# RCC — Target Cliente

## Cliente Ideal (MVP)

Empresas con:

- Equipos humanos de soporte o coordinación
- Más de 5 personas interactuando por chat
- Uso intensivo de Slack / Chat / Email

## Problema Principal

- Conversaciones tensas
- Escaladas frecuentes
- Malentendidos constantes
- Agotamiento del equipo

## Buyer Persona

- Head of Support
- COO
- Founder técnico

## Dolor que compra

"No necesito más bots.
Necesito que mi gente se comunique mejor."

## Qué NO es target (por ahora)

- Chatbots automáticos
- Atención 100% IA
- Redes sociales abiertas
