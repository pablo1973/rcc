import { InputMessage, Channel } from "../core/types";
import { CognitiveState } from "../core/states";
import { analyze, AnalysisResult } from "../core/analyzer";
import { regulate, RegulationResult } from "../core/regulator";

describe("RCC Smoke Test", () => {
  const mockInput: InputMessage = {
    id: "test-1",
    text: "Hello world",
    author: "user",
    channel: "cli" as Channel,
    timestamp: Date.now(),
  };

  test("types are defined", () => {
    expect(mockInput.id).toBe("test-1");
    expect(mockInput.channel).toBe("cli");
  });

  test("CognitiveState type exists", () => {
    const state: CognitiveState = "NEUTRAL";
    expect(["CALM", "NEUTRAL", "TENSE"]).toContain(state);
  });

  test("analyze returns AnalysisResult with NEUTRAL state", () => {
    const result: AnalysisResult = analyze(mockInput.text);
    expect(result.state).toBe("NEUTRAL");
    expect(result.regulatedText).toBe("Hello world");
  });

  test("regulate returns RegulationResult with regulated text", () => {
    const analysis: AnalysisResult = { state: "NEUTRAL", regulatedText: "Hello world" };
    const result: RegulationResult = regulate(mockInput, analysis);
    expect(result.outputText).toBe("Hello world");
  });

  test("pipeline: input -> analyze -> regulate", () => {
    const input: InputMessage = {
      id: "pipe-1",
      text: "Test message",
      author: "tester",
      channel: "slack",
      timestamp: Date.now(),
    };
    const analysis = analyze(input.text);
    const result = regulate(input, analysis);
    expect(analysis.state).toBe("NEUTRAL");
    expect(result.outputText).toBe("Test message");
  });
});
