import { InputMessage } from "./types";
import { AnalysisResult } from "./analyzer";
export interface RegulationResult {
  outputText: string;
}
export function regulate(
  input: InputMessage,
  analysis: AnalysisResult
): RegulationResult {
  return {
    outputText: analysis.regulatedText,
  };
}
