import { State } from "./states";
export type Metrics = {
  chars: number;
  words: number;
  intensity: number;   // 0..1
  repetition: number;  // 0..1
  noise: number;       // 0..1
};
export function computeMetrics(text: string): Metrics {
  return {
    chars: 0,
    words: 0,
    intensity: 0,
    repetition: 0,
    noise: 0,
  };
}
export function resolveState(metrics: Metrics): State {
  return "NEUTRAL";
}
