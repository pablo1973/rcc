export type CognitiveState = "CALM" | "NEUTRAL" | "TENSE";
export type State = CognitiveState;
