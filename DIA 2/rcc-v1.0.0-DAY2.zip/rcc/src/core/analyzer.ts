import { computeMetrics, resolveState } from "./heuristics";
import { applyRules } from "./rules";
import { State } from "./states";
export type AnalysisResult = {
  state: State;
  regulatedText: string;
};
export function analyze(text: string): AnalysisResult {
  const metrics = computeMetrics(text);
  const state = resolveState(metrics);
  const regulatedText = applyRules(text, state);
  return { state, regulatedText };
}
