import { analyze, AnalysisResult } from "../core/analyzer";
import { computeMetrics, resolveState, Metrics } from "../core/heuristics";

describe("Analyzer", () => {
  describe("computeMetrics - métricas básicas", () => {
    test("returns zero metrics for empty string", () => {
      const metrics = computeMetrics("");
      expect(metrics.chars).toBe(0);
      expect(metrics.words).toBe(0);
      expect(metrics.intensity).toBe(0);
      expect(metrics.repetition).toBe(0);
      expect(metrics.noise).toBe(0);
    });

    test("returns metrics structure", () => {
      const metrics = computeMetrics("hello world");
      expect(metrics).toHaveProperty("chars");
      expect(metrics).toHaveProperty("words");
      expect(metrics).toHaveProperty("intensity");
      expect(metrics).toHaveProperty("repetition");
      expect(metrics).toHaveProperty("noise");
    });

    test("intensity is between 0 and 1", () => {
      const metrics = computeMetrics("TEST!!!");
      expect(metrics.intensity).toBeGreaterThanOrEqual(0);
      expect(metrics.intensity).toBeLessThanOrEqual(1);
    });

    test("repetition is between 0 and 1", () => {
      const metrics = computeMetrics("aaa bbb aaa");
      expect(metrics.repetition).toBeGreaterThanOrEqual(0);
      expect(metrics.repetition).toBeLessThanOrEqual(1);
    });

    test("noise is between 0 and 1", () => {
      const metrics = computeMetrics("!!!???...");
      expect(metrics.noise).toBeGreaterThanOrEqual(0);
      expect(metrics.noise).toBeLessThanOrEqual(1);
    });
  });

  describe("resolveState - clasificación CALM / NEUTRAL / TENSE", () => {
    test("returns NEUTRAL for zero metrics", () => {
      const metrics: Metrics = {
        chars: 0,
        words: 0,
        intensity: 0,
        repetition: 0,
        noise: 0,
      };
      expect(resolveState(metrics)).toBe("NEUTRAL");
    });

    test("returns valid state type", () => {
      const metrics: Metrics = {
        chars: 10,
        words: 2,
        intensity: 0.5,
        repetition: 0.3,
        noise: 0.2,
      };
      const state = resolveState(metrics);
      expect(["CALM", "NEUTRAL", "TENSE"]).toContain(state);
    });

    test("is deterministic - same input produces same output", () => {
      const metrics: Metrics = {
        chars: 20,
        words: 4,
        intensity: 0.7,
        repetition: 0.5,
        noise: 0.3,
      };
      const state1 = resolveState(metrics);
      const state2 = resolveState(metrics);
      expect(state1).toBe(state2);
    });
  });

  describe("analyze - edge cases", () => {
    test("handles empty string", () => {
      const result: AnalysisResult = analyze("");
      expect(result.state).toBe("NEUTRAL");
      expect(result.regulatedText).toBe("");
    });

    test("handles string with only spaces", () => {
      const result: AnalysisResult = analyze("   ");
      expect(result).toHaveProperty("state");
      expect(result).toHaveProperty("regulatedText");
    });

    test("handles uppercase text", () => {
      const result: AnalysisResult = analyze("HELLO WORLD");
      expect(["CALM", "NEUTRAL", "TENSE"]).toContain(result.state);
      expect(typeof result.regulatedText).toBe("string");
    });

    test("handles repeated signs", () => {
      const result: AnalysisResult = analyze("Hello!!!!!????");
      expect(["CALM", "NEUTRAL", "TENSE"]).toContain(result.state);
      expect(typeof result.regulatedText).toBe("string");
    });

    test("handles mixed case and punctuation", () => {
      const result: AnalysisResult = analyze("HeLLo WoRLD!!!");
      expect(result).toHaveProperty("state");
      expect(result).toHaveProperty("regulatedText");
    });

    test("preserves original text in baseline (no transformation)", () => {
      const input = "Test message";
      const result = analyze(input);
      expect(result.regulatedText).toBe(input);
    });
  });

  describe("analyze - full pipeline", () => {
    test("returns AnalysisResult with state and regulatedText", () => {
      const result = analyze("Hello world");
      expect(result).toHaveProperty("state");
      expect(result).toHaveProperty("regulatedText");
    });

    test("pipeline is deterministic", () => {
      const input = "Deterministic test";
      const result1 = analyze(input);
      const result2 = analyze(input);
      expect(result1.state).toBe(result2.state);
      expect(result1.regulatedText).toBe(result2.regulatedText);
    });
  });
});
